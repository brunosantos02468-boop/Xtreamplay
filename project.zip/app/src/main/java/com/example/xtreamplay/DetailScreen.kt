package com.example.xtreamplay

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

private val Red = Color(0xFFE50914)

@Composable
fun DetailScreen(vm: AppViewModel, cur: Item) {
    BackHandler { vm.closeDetail() }
    val isTv = LocalIsTv.current
    val playFocus = remember { FocusRequester() }
    LaunchedEffect(cur.id) {
        if (isTv) { delay(250); runCatching { playFocus.requestFocus() } }
    }
    val ctx = LocalContext.current
    val info = vm.detailInfo
    val resume = vm.recent.firstOrNull { it.item.id == cur.id && it.item.kind == cur.kind }
    val similar = remember(cur, vm.derived[cur.kind]) { vm.similar(cur) }
    val meta = listOfNotNull(
        info?.year?.takeIf { it.isNotBlank() },
        info?.genre?.takeIf { it.isNotBlank() },
        info?.duration?.takeIf { it.isNotBlank() },
        info?.rating?.takeIf { it.isNotBlank() && it != "0" }?.let { "★ $it" }
    ).joinToString("  ·  ")

    key(cur.id) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            LazyColumn(Modifier.fillMaxSize()) {
                item {
                    Box(Modifier.fillMaxWidth().height(if (isTv) 200.dp else 260.dp)) {
                        AsyncImage(info?.backdrop ?: cur.image, cur.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        Box(
                            Modifier.fillMaxSize().background(
                                Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent, Color.Black))
                            )
                        )
                        TextButton(
                            onClick = { vm.closeDetail() },
                            modifier = Modifier.align(Alignment.TopStart).statusBarsPadding().tvFocusRing(RoundedCornerShape(50))
                        ) { Text("←", color = Color.White, fontSize = 26.sp) }
                    }
                }
                item {
                    Column(Modifier.padding(horizontal = 16.dp)) {
                        Text(cur.name, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                        if (meta.isNotBlank()) Text(meta, color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        Spacer(Modifier.height(14.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                modifier = Modifier.tvFocusRing(RoundedCornerShape(50)).focusRequester(playFocus),
                                onClick = {
                                    when {
                                        resume != null -> vm.resume(resume)
                                        cur.kind == Kind.MOVIE -> vm.playMovie(cur)
                                        else -> vm.episodes.firstOrNull()?.let { vm.playEpisode(it) }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                            ) { Text(if (resume != null) "▶  Continuar" else "▶  Assistir", fontWeight = FontWeight.Bold) }

                            Button(
                                modifier = Modifier.tvFocusRing(RoundedCornerShape(50)),
                                onClick = { vm.toggleFav(cur) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333), contentColor = Color.White)
                            ) { Text(if (vm.isFav(cur)) "✓  Minha lista" else "+  Minha lista") }

                            val trailer = info?.trailer.orEmpty()
                            if (trailer.isNotBlank()) Button(
                                modifier = Modifier.tvFocusRing(RoundedCornerShape(50)),
                                onClick = {
                                    val url = if (trailer.startsWith("http")) trailer else "https://www.youtube.com/watch?v=$trailer"
                                    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333), contentColor = Color.White)
                            ) { Text("Trailer") }
                        }

                        Spacer(Modifier.height(14.dp))
                        if (info == null) CircularProgressIndicator(color = Red)
                        else {
                            if (info.plot.isNotBlank()) Text(info.plot, color = Color.LightGray, fontSize = 14.sp, lineHeight = 20.sp)
                            if (info.cast.isNotBlank()) Text("Elenco: ${info.cast}", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
                            if (info.director.isNotBlank()) Text("Direção: ${info.director}", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }

                if (cur.kind == Kind.SERIES) {
                    if (info != null && vm.episodes.isEmpty()) item {
                        Text("Nenhum episódio encontrado", color = Color.Gray, modifier = Modifier.padding(16.dp))
                    }
                    vm.episodes.groupBy { it.season }.forEach { (season, list) ->
                        item {
                            Text(
                                "Temporada $season", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                                modifier = Modifier.padding(start = 16.dp, top = 20.dp, bottom = 4.dp)
                            )
                        }
                        items(list) { ep ->
                            Text(
                                "▶   ${ep.title}", color = Color.LightGray,
                                modifier = Modifier.fillMaxWidth().tvClickable { vm.playEpisode(ep) }
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                            )
                        }
                    }
                }

                if (similar.isNotEmpty()) item { PosterRow("Títulos semelhantes", similar, vm) }
                item { Spacer(Modifier.height(40.dp)) }
            }
        }
    }
}
