package com.example.xtreamplay

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/**
 * Ícones de navegação minimalistas, de traço fino.
 * Selecionado = preenchido (ou traço mais grosso); não selecionado = só contorno.
 */
@Composable
fun NavIcon(screen: Screen, selected: Boolean, tint: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(24.dp)) {
        val k = size.width / 24f
        val stroke = Stroke(
            width = (if (selected) 2.2f else 1.8f) * k,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )

        fun poly(pts: List<Pair<Float, Float>>, fill: Boolean) {
            val p = Path()
            pts.forEachIndexed { i, (x, y) ->
                if (i == 0) p.moveTo(x * k, y * k) else p.lineTo(x * k, y * k)
            }
            p.close()
            if (fill) drawPath(p, tint) else drawPath(p, tint, style = stroke)
        }

        when (screen) {
            Screen.HOME -> poly(
                listOf(
                    4f to 11f, 12f to 4f, 20f to 11f, 20f to 20f,
                    14.5f to 20f, 14.5f to 14f, 9.5f to 14f, 9.5f to 20f, 4f to 20f
                ), selected
            )
            Screen.NEWS -> poly(
                listOf(
                    12f to 3f, 14f to 10f, 21f to 12f, 14f to 14f,
                    12f to 21f, 10f to 14f, 3f to 12f, 10f to 10f
                ), selected
            )
            Screen.SEARCH -> {
                drawCircle(tint, radius = 6.5f * k, center = Offset(10.5f * k, 10.5f * k), style = stroke)
                drawLine(tint, Offset(15.5f * k, 15.5f * k), Offset(20.5f * k, 20.5f * k), strokeWidth = stroke.width, cap = StrokeCap.Round)
            }
            Screen.LIST -> poly(
                listOf(7f to 4f, 17f to 4f, 17f to 20f, 12f to 16f, 7f to 20f), selected
            )
            Screen.MORE -> listOf(7f, 12f, 17f).forEach { y ->
                drawLine(tint, Offset(5f * k, y * k), Offset(19f * k, y * k), strokeWidth = stroke.width, cap = StrokeCap.Round)
            }
        }
    }
}
