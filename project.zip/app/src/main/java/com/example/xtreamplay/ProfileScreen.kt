package com.example.xtreamplay

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val palette = listOf(
    Color(0xFFE50914), Color(0xFF2196F3), Color(0xFF4CAF50), Color(0xFFFFC107), Color(0xFF9C27B0)
)

fun profileColor(p: Profile?): Color = palette[(p?.color ?: 0) % palette.size]

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ProfileScreen(vm: AppViewModel) {
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Profile?>(null) }
    var pinTarget by remember { mutableStateOf<Profile?>(null) }

    Column(
        Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Quem está assistindo?", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(32.dp))

        LazyRow(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(22.dp, Alignment.CenterHorizontally)
        ) {
            items(vm.profiles.toList()) { p ->
                Column(
                    Modifier.combinedClickable(
                        onClick = { if (p.pin.isNotEmpty()) pinTarget = p else vm.selectProfile(p) },
                        onLongClick = { if (vm.profiles.size > 1) deleting = p }
                    ),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Avatar(p.name, 96, profileColor(p))
                    Spacer(Modifier.height(8.dp))
                    Text(p.name, color = Color.LightGray, fontSize = 15.sp)
                    val tag = listOfNotNull(if (p.kids) "Infantil" else null, if (p.pin.isNotEmpty()) "🔒" else null)
                        .joinToString(" ")
                    if (tag.isNotEmpty()) Text(tag, color = Color.Gray, fontSize = 12.sp)
                }
            }
            if (vm.profiles.size < 5) item {
                Column(Modifier.clickable { adding = true }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(96.dp).clip(RoundedCornerShape(4.dp))
                            .border(1.dp, Color.Gray, RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text("+", color = Color.Gray, fontSize = 40.sp) }
                    Spacer(Modifier.height(8.dp))
                    Text("Adicionar", color = Color.Gray, fontSize = 15.sp)
                }
            }
        }

        if (vm.profiles.size > 1) {
            Spacer(Modifier.height(32.dp))
            Text("Segure um perfil para excluir", color = Color(0xFF777777), fontSize = 12.sp)
        }
    }

    if (adding) {
        var name by remember { mutableStateOf("") }
        var kids by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { adding = false },
            containerColor = Color(0xFF141414),
            title = { Text("Novo perfil", color = Color.White) },
            text = {
                Column {
                    OutlinedTextField(name, { name = it.take(14) }, singleLine = true, label = { Text("Nome") })
                    Row(
                        Modifier.fillMaxWidth().padding(top = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Perfil infantil", color = Color.White)
                            Text("Mostra só categorias infantis", color = Color.Gray, fontSize = 12.sp)
                        }
                        Switch(
                            kids, { kids = it },
                            colors = SwitchDefaults.colors(checkedTrackColor = Color(0xFFE50914), checkedThumbColor = Color.White)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.addProfile(name, kids); adding = false }) {
                    Text("Criar", color = Color.White)
                }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancelar", color = Color.Gray) } }
        )
    }

    deleting?.let { p ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            containerColor = Color(0xFF141414),
            title = { Text("Excluir perfil?", color = Color.White) },
            text = { Text("\"${p.name}\" e a lista de favoritos dele serão apagados.", color = Color.LightGray) },
            confirmButton = {
                TextButton(onClick = { vm.deleteProfile(p); deleting = null }) {
                    Text("Excluir", color = Color(0xFFFF6B6B))
                }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancelar", color = Color.Gray) } }
        )
    }

    pinTarget?.let { p ->
        var pin by remember { mutableStateOf("") }
        var wrong by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { pinTarget = null },
            containerColor = Color(0xFF141414),
            title = { Text("PIN de ${p.name}", color = Color.White) },
            text = {
                Column {
                    OutlinedTextField(
                        pin, { pin = it.filter { c -> c.isDigit() }.take(4); wrong = false },
                        singleLine = true, label = { Text("PIN de 4 dígitos") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation()
                    )
                    if (wrong) Text("PIN incorreto", color = Color(0xFFFF6B6B), modifier = Modifier.padding(top = 8.dp))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (pin == p.pin) { pinTarget = null; vm.selectProfile(p) } else wrong = true
                }) { Text("Entrar", color = Color.White) }
            },
            dismissButton = { TextButton(onClick = { pinTarget = null }) { Text("Cancelar", color = Color.Gray) } }
        )
    }
}
