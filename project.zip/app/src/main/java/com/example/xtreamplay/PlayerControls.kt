package com.example.xtreamplay

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val CtlRed = Color(0xFFFF453A)

enum class CtlKind { PLAY, PAUSE, PREV, NEXT, BACK, FORWARD }

/** Ícones desenhados à mão (não dependem de fontes/emojis da TV). */
@Composable
fun CtlIcon(kind: CtlKind, tint: Color, iconSize: Dp = 28.dp) {
    Canvas(Modifier.size(iconSize)) {
        val w = size.width
        val h = size.height
        fun tri(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
            val p = Path().apply {
                moveTo(w * x1, h * y1); lineTo(w * x2, h * y2); lineTo(w * x3, h * y3); close()
            }
            drawPath(p, tint)
        }
        fun bar(x: Float, wd: Float) =
            drawRoundRect(tint, Offset(w * x, h * 0.16f), Size(w * wd, h * 0.68f), CornerRadius(w * 0.05f))
        when (kind) {
            CtlKind.PLAY -> tri(0.24f, 0.12f, 0.24f, 0.88f, 0.90f, 0.50f)
            CtlKind.PAUSE -> { bar(0.20f, 0.20f); bar(0.60f, 0.20f) }
            CtlKind.NEXT -> { tri(0.10f, 0.16f, 0.10f, 0.84f, 0.68f, 0.50f); bar(0.74f, 0.15f) }
            CtlKind.PREV -> { tri(0.90f, 0.16f, 0.90f, 0.84f, 0.32f, 0.50f); bar(0.11f, 0.15f) }
            CtlKind.BACK -> {
                tri(0.06f, 0.50f, 0.50f, 0.20f, 0.50f, 0.80f)
                tri(0.50f, 0.50f, 0.94f, 0.20f, 0.94f, 0.80f)
            }
            CtlKind.FORWARD -> {
                tri(0.94f, 0.50f, 0.50f, 0.20f, 0.50f, 0.80f)
                tri(0.50f, 0.50f, 0.06f, 0.20f, 0.06f, 0.80f)
            }
        }
    }
}

@Composable
private fun CtlButton(
    kind: CtlKind,
    enabled: Boolean,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier.size(60.dp)
                .tvFocusRing(CircleShape)
                .clip(CircleShape)
                .background(if (focused) Color.White else Color(0x33FFFFFF))
                .onFocusChanged { focused = it.isFocused }
                .clickable(enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            CtlIcon(
                kind,
                if (focused) Color.Black else Color.White.copy(alpha = if (enabled) 1f else 0.3f)
            )
        }
        Text(
            label, color = if (enabled) Color(0xFFCCCCCC) else Color(0xFF666666),
            fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
        )
    }
}

fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

/** Barra de controles do player para TV: anterior, -10 s, play/pause, +10 s, próximo (todos selecionáveis pelo controle). */
@Composable
fun TvControlsBar(
    isPlaying: Boolean,
    posMs: Long,
    durMs: Long,
    hasPrev: Boolean,
    hasNext: Boolean,
    playFocus: FocusRequester,
    onPrev: () -> Unit,
    onBack10: () -> Unit,
    onPlayPause: () -> Unit,
    onForward10: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
            .padding(horizontal = 48.dp, vertical = 20.dp)
    ) {
        if (durMs > 0) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(fmtTime(posMs), color = Color.White, fontSize = 13.sp)
                Box(
                    Modifier.weight(1f).padding(horizontal = 12.dp).height(5.dp)
                        .clip(RoundedCornerShape(3.dp)).background(Color(0x55FFFFFF))
                ) {
                    Box(
                        Modifier.fillMaxHeight()
                            .fillMaxWidth((posMs.toFloat() / durMs).coerceIn(0f, 1f))
                            .background(Color.White)
                    )
                }
                Text(fmtTime(durMs), color = Color.White, fontSize = 13.sp)
            }
        } else {
            Text("AO VIVO", color = CtlRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(22.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.Top
        ) {
            CtlButton(CtlKind.PREV, hasPrev, "Anterior", onClick = onPrev)
            CtlButton(CtlKind.BACK, true, "-10 s", onClick = onBack10)
            CtlButton(
                if (isPlaying) CtlKind.PAUSE else CtlKind.PLAY, true,
                if (isPlaying) "Pausar" else "Assistir",
                Modifier.focusRequester(playFocus), onClick = onPlayPause
            )
            CtlButton(CtlKind.FORWARD, true, "+10 s", onClick = onForward10)
            CtlButton(CtlKind.NEXT, hasNext, "Próximo", onClick = onNext)
        }
    }
}
