package com.example.xtreamplay

import androidx.compose.ui.graphics.Color

/** Paleta no estilo Apple TV (tvOS): fundo preto, superfícies cinza-escuro e destaque branco. */
object Atv {
    val Surface = Color(0xFF1C1C1E)
    val SurfaceHi = Color(0xFF2C2C2E)
    val Divider = Color(0xFF38383A)
    val TextSecondary = Color(0xFF8E8E93)
    val Green = Color(0xFF30D158)
    val Red = Color(0xFFFF453A)
    val Blue = Color(0xFF0A84FF)
}
