package com.example.xtreamplay

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private val navItems = listOf(
    Triple(Screen.HOME, "🏠", "Início"),
    Triple(Screen.NEWS, "🔥", "Novidades"),
    Triple(Screen.SEARCH, "🔍", "Buscar"),
    Triple(Screen.LIST, "➕", "Minha lista"),
    Triple(Screen.MORE, "☰", "Mais")
)

@Composable
fun MainScaffold(vm: AppViewModel) {
    val isTv = LocalIsTv.current
    val railReq = remember { FocusRequester() }
    val contentReq = remember { FocusRequester() }
    var railFocused by remember { mutableStateOf(false) }

    // TV: "Voltar" primeiro leva o foco ao menu lateral; depois volta ao Início; depois sai do app
    BackHandler(enabled = vm.detail == null && (vm.screen != Screen.HOME || (isTv && !railFocused))) {
        if (isTv && !railFocused) runCatching { railReq.requestFocus() } else vm.go(Screen.HOME)
    }

    // TV: ao abrir o app, trocar de aba ou fechar os detalhes, o foco vai para o conteúdo
    LaunchedEffect(vm.screen, vm.detail == null) {
        if (isTv && vm.detail == null) { delay(350); runCatching { contentReq.requestFocus() } }
    }
    // Enquanto a tela de detalhes está aberta, o controle remoto não "escapa" para a tela de trás
    val focusGuard = if (vm.detail != null) Modifier.focusProperties { canFocus = false } else Modifier

    Box(Modifier.fillMaxSize()) {
        if (isTv) {
            Row(Modifier.fillMaxSize().background(Color.Black).then(focusGuard)) {
                NavigationRail(
                    containerColor = Color(0xFF0B0B0B),
                    modifier = Modifier.fillMaxHeight()
                        .onFocusChanged { railFocused = it.hasFocus }
                        .focusRequester(railReq)
                        .focusGroup()
                ) {
                    Spacer(Modifier.weight(1f))
                    navItems.forEach { (s, _, label) ->
                        NavigationRailItem(
                            selected = vm.screen == s,
                            onClick = { vm.go(s) },
                            icon = { NavIcon(s, vm.screen == s, if (vm.screen == s) Color.White else Color(0xFF9E9E9E)) },
                            label = { Text(label, fontSize = 11.sp, maxLines = 1) },
                            alwaysShowLabel = true,
                            modifier = Modifier.focusProperties { right = contentReq }.tvFocusRing(RoundedCornerShape(16.dp)),
                            colors = NavigationRailItemDefaults.colors(
                                selectedTextColor = Color.White,
                                unselectedTextColor = Color.Gray,
                                indicatorColor = Color(0xFF2A2A2A)
                            )
                        )
                    }
                    Spacer(Modifier.weight(1f))
                }
                Box(Modifier.weight(1f).fillMaxHeight().focusRequester(contentReq).focusGroup()) { ScreenContent(vm) }
            }
        } else {
            Scaffold(
                modifier = focusGuard,
                containerColor = Color.Black,
                contentWindowInsets = WindowInsets(0),
                bottomBar = {
                    NavigationBar(containerColor = Color(0xFF0B0B0B), tonalElevation = 0.dp) {
                        navItems.forEach { (s, _, label) ->
                            NavigationBarItem(
                                selected = vm.screen == s,
                                onClick = { vm.go(s) },
                                icon = { NavIcon(s, vm.screen == s, if (vm.screen == s) Color.White else Color(0xFF9E9E9E)) },
                                label = { Text(label, fontSize = 11.sp, maxLines = 1) },
                                alwaysShowLabel = false,
                                colors = NavigationBarItemDefaults.colors(
                                    selectedTextColor = Color.White,
                                    unselectedTextColor = Color.Gray,
                                    indicatorColor = Color(0xFF2A2A2A)
                                )
                            )
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) { ScreenContent(vm) }
            }
        }
        vm.detail?.let { DetailScreen(vm, it) }
    }
}

@Composable
private fun ScreenContent(vm: AppViewModel) {
    when (vm.screen) {
        Screen.HOME -> HomeScreen(vm)
        Screen.NEWS -> NewsScreen(vm)
        Screen.SEARCH -> SearchScreen(vm)
        Screen.LIST -> MyListScreen(vm)
        Screen.MORE -> SettingsScreen(vm)
    }
}

@Composable
fun NewsScreen(vm: AppViewModel) {
    val movies = vm.news(Kind.MOVIE)
    val series = vm.news(Kind.SERIES)

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        Text(
            "Novidades", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp)
        )
        if (movies.isEmpty() && series.isEmpty()) {
            Hint(if (vm.loading) "Carregando listas…" else "Nada por aqui ainda")
        } else LazyColumn(Modifier.fillMaxSize()) {
            if (movies.isNotEmpty()) item { PosterRow("Filmes adicionados recentemente", movies, vm) }
            if (series.isNotEmpty()) item { PosterRow("Séries atualizadas recentemente", series, vm) }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
fun SearchScreen(vm: AppViewModel) {
    var q by remember { mutableStateOf("") }
    val pool = remember(vm.derived[Kind.LIVE], vm.derived[Kind.MOVIE], vm.derived[Kind.SERIES]) {
        Kind.values().flatMap { vm.visibleItems(it) }
    }
    // busca feita em segundo plano, com pequena espera enquanto você digita
    val results by produceState(emptyList<Item>(), q, pool) {
        val t = q.trim()
        if (t.length < 2) { value = emptyList(); return@produceState }
        delay(250)
        value = withContext(Dispatchers.Default) {
            pool.filter { it.name.contains(t, ignoreCase = true) }
                .distinctBy { it.kind to it.id }.take(150)
        }
    }

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        OutlinedTextField(
            q, { q = it }, singleLine = true,
            placeholder = { Text("Buscar canais, filmes e séries") },
            modifier = Modifier.fillMaxWidth().padding(12.dp).tvKeyboardOnOk()
        )
        when {
            q.trim().length < 2 -> Hint(if (vm.loading) "Carregando listas…" else "Digite pelo menos 2 letras")
            results.isEmpty() -> Hint(if (vm.loading) "Carregando listas…" else "Nada encontrado")
            else -> LazyVerticalGrid(
                GridCells.Adaptive(150.dp),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(results) { Poster(it, vm.isFav(it), { vm.toggleFav(it) }) { vm.open(it) } }
            }
        }
    }
}

@Composable
fun MyListScreen(vm: AppViewModel) {
    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        Text(
            "Minha lista", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp)
        )
        Text(
            if (LocalIsTv.current) "Segure o OK em qualquer item (ou use o botão na tela do título) para adicionar ou remover"
            else "Toque no ♥ de qualquer item para adicionar ou remover",
            color = Color.Gray, fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        if (vm.favorites.isEmpty()) Hint("Sua lista está vazia")
        else LazyVerticalGrid(
            GridCells.Adaptive(150.dp),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(vm.favorites.toList()) { Poster(it, vm.isFav(it), { vm.toggleFav(it) }) { vm.open(it) } }
        }
    }
}

@Composable
private fun Hint(text: String) {
    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Color.Gray)
    }
}
