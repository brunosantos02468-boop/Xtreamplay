package com.example.xtreamplay

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private val navItems = listOf(
    Triple(Screen.HOME, "🏠", "Início"),
    Triple(Screen.NEWS, "🔥", "Novidades"),
    Triple(Screen.SEARCH, "🔍", "Buscar"),
    Triple(Screen.LIST, "➕", "Minha lista"),
    Triple(Screen.MORE, "☰", "Mais")
)

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun MainScaffold(vm: AppViewModel) {
    val isTv = LocalIsTv.current
    val railReq = remember { FocusRequester() }
    val contentReq = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var railOpen by remember { mutableStateOf(false) }
    var railHadFocus by remember { mutableStateOf(false) }

    // TV: "Voltar" abre o menu lateral; com o menu aberto volta ao Início; no Início sai do app
    BackHandler(enabled = vm.detail == null && (vm.screen != Screen.HOME || (isTv && !railOpen))) {
        if (isTv && !railOpen) railOpen = true else if (isTv && railOpen) {
            railOpen = false
            if (vm.screen != Screen.HOME) vm.go(Screen.HOME)
        } else vm.go(Screen.HOME)
    }

    // TV: ao abrir o app, trocar de aba, fechar o menu ou os detalhes, o foco vai para o conteúdo
    LaunchedEffect(vm.screen, vm.detail == null, railOpen) {
        if (isTv && vm.detail == null && !railOpen) { delay(350); runCatching { contentReq.requestFocus() } }
    }
    // Menu aberto: o foco vai para ele
    LaunchedEffect(railOpen) {
        if (railOpen) { delay(60); runCatching { railReq.requestFocus() } }
    }
    // Enquanto a tela de detalhes está aberta, o controle remoto não "escapa" para a tela de trás
    val focusGuard = if (vm.detail != null) Modifier.focusProperties { canFocus = false } else Modifier

    Box(Modifier.fillMaxSize()) {
        if (isTv) {
            // Conteúdo ocupa a tela toda; seta ← na borda esquerda (ou Voltar) abre o menu
            Box(
                Modifier.fillMaxSize().background(Color.Black).then(focusGuard)
                    .onKeyEvent { e ->
                        if (e.type == KeyEventType.KeyDown && e.key == Key.DirectionLeft && !railOpen) {
                            if (!focusManager.moveFocus(FocusDirection.Left)) railOpen = true
                            true
                        } else false
                    }
                    .focusRequester(contentReq)
                    .focusGroup()
            ) { ScreenContent(vm) }

            if (railOpen) {
                NavigationRail(
                    containerColor = Color(0xF21C1C1E),
                    modifier = Modifier.align(Alignment.CenterStart).fillMaxHeight()
                        .onFocusChanged {
                            if (it.hasFocus) railHadFocus = true
                            else if (railHadFocus) { railHadFocus = false; railOpen = false }
                        }
                        .focusRequester(railReq)
                        .focusGroup()
                        .onKeyEvent { e ->
                            if (e.type == KeyEventType.KeyDown && e.key == Key.DirectionRight) {
                                railOpen = false; true
                            } else false
                        }
                ) {
                    Spacer(Modifier.weight(1f))
                    navItems.forEach { (s, _, label) ->
                        NavigationRailItem(
                            selected = vm.screen == s,
                            onClick = { vm.go(s); railOpen = false },
                            icon = { NavIcon(s, vm.screen == s, if (vm.screen == s) Color.White else Color(0xFF9E9E9E)) },
                            label = { Text(label, fontSize = 11.sp, maxLines = 1) },
                            alwaysShowLabel = true,
                            modifier = Modifier.tvFocusRing(RoundedCornerShape(16.dp)),
                            colors = NavigationRailItemDefaults.colors(
                                selectedTextColor = Color.White,
                                unselectedTextColor = Color.Gray,
                                indicatorColor = Color(0xFF3A3A3C)
                            )
                        )
                    }
                    Spacer(Modifier.weight(1f))
                }
            }
        } else {
            Scaffold(
                modifier = focusGuard,
                containerColor = Color.Black,
                contentWindowInsets = WindowInsets(0),
                bottomBar = {
                    NavigationBar(containerColor = Atv.Surface, tonalElevation = 0.dp) {
                        navItems.forEach { (s, _, label) ->
                            NavigationBarItem(
                                selected = vm.screen == s,
                                onClick = { vm.go(s) },
                                icon = { NavIcon(s, vm.screen == s, if (vm.screen == s) Color.White else Color(0xFF9E9E9E)) },
                                label = { Text(label, fontSize = 11.sp, maxLines = 1) },
                                alwaysShowLabel = false,
                                colors = NavigationBarItemDefaults.colors(
                                    selectedTextColor = Color.White,
                                    unselectedTextColor = Color.Gray,
                                    indicatorColor = Color(0xFF3A3A3C)
                                )
                            )
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) { ScreenContent(vm) }
            }
        }
        vm.detail?.let { DetailScreen(vm, it) }
    }
}

@Composable
private fun ScreenContent(vm: AppViewModel) {
    when (vm.screen) {
        Screen.HOME -> HomeScreen(vm)
        Screen.NEWS -> NewsScreen(vm)
        Screen.SEARCH -> SearchScreen(vm)
        Screen.LIST -> MyListScreen(vm)
        Screen.MORE -> SettingsScreen(vm)
    }
}

@Composable
fun NewsScreen(vm: AppViewModel) {
    val movies = vm.news(Kind.MOVIE)
    val series = vm.news(Kind.SERIES)

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        Text(
            "Novidades", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp)
        )
        if (movies.isEmpty() && series.isEmpty()) {
            Hint(if (vm.loading) "Carregando listas…" else "Nada por aqui ainda")
        } else LazyColumn(Modifier.fillMaxSize()) {
            if (movies.isNotEmpty()) item { PosterRow(Shelf("Filmes adicionados recentemente", movies), vm) }
            if (series.isNotEmpty()) item { PosterRow(Shelf("Séries atualizadas recentemente", series), vm) }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
fun SearchScreen(vm: AppViewModel) {
    var q by remember { mutableStateOf("") }
    val pool = remember(vm.derived[Kind.LIVE], vm.derived[Kind.MOVIE], vm.derived[Kind.SERIES]) {
        Kind.values().flatMap { vm.visibleItems(it) }
    }
    // busca feita em segundo plano, com pequena espera enquanto você digita
    val results by produceState(emptyList<Item>(), q, pool) {
        val t = q.trim()
        if (t.length < 2) { value = emptyList(); return@produceState }
        delay(250)
        value = withContext(Dispatchers.Default) {
            pool.filter { it.name.contains(t, ignoreCase = true) }
                .distinctBy { it.kind to it.id }.take(150)
        }
    }

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        OutlinedTextField(
            q, { q = it }, singleLine = true,
            placeholder = { Text("Buscar canais, filmes e séries") },
            modifier = Modifier.fillMaxWidth().padding(12.dp).tvKeyboardOnOk()
        )
        when {
            q.trim().length < 2 -> Hint(if (vm.loading) "Carregando listas…" else "Digite pelo menos 2 letras")
            results.isEmpty() -> Hint(if (vm.loading) "Carregando listas…" else "Nada encontrado")
            else -> LazyVerticalGrid(
                GridCells.Adaptive(150.dp),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(results) { Poster(it, vm.isFav(it), { vm.toggleFav(it) }) { vm.open(it) } }
            }
        }
    }
}

@Composable
fun MyListScreen(vm: AppViewModel) {
    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        Text(
            "Minha lista", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp)
        )
        Text(
            if (LocalIsTv.current) "Segure o OK em qualquer item (ou use o botão na tela do título) para adicionar ou remover"
            else "Toque no ♥ de qualquer item para adicionar ou remover",
            color = Color.Gray, fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        if (vm.favorites.isEmpty()) Hint("Sua lista está vazia")
        else LazyVerticalGrid(
            GridCells.Adaptive(150.dp),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(vm.favorites.toList()) { Poster(it, vm.isFav(it), { vm.toggleFav(it) }) { vm.open(it) } }
        }
    }
}

@Composable
private fun Hint(text: String) {
    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Color.Gray)
    }
}
