package com.example.xtreamplay

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val navItems = listOf(
    Triple(Screen.HOME, "🏠", "Início"),
    Triple(Screen.SEARCH, "🔍", "Buscar"),
    Triple(Screen.LIST, "➕", "Minha lista"),
    Triple(Screen.MORE, "☰", "Mais")
)

@Composable
fun MainScaffold(vm: AppViewModel) {
    BackHandler(enabled = vm.screen != Screen.HOME) { vm.go(Screen.HOME) }

    Scaffold(
        containerColor = Color.Black,
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0B0B0B)) {
                navItems.forEach { (s, icon, label) ->
                    NavigationBarItem(
                        selected = vm.screen == s,
                        onClick = { vm.go(s) },
                        icon = { Text(icon, fontSize = 20.sp) },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedTextColor = Color.White,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFF2A2A2A)
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (vm.screen) {
                Screen.HOME -> HomeScreen(vm)
                Screen.SEARCH -> SearchScreen(vm)
                Screen.LIST -> MyListScreen(vm)
                Screen.MORE -> SettingsScreen(vm)
            }
        }
    }
    vm.openSeries?.let { SeriesDialog(vm) }
}

@Composable
fun SearchScreen(vm: AppViewModel) {
    var q by remember { mutableStateOf("") }
    val all = Kind.values().flatMap { k -> vm.shelves[k].orEmpty().flatMap { it.items } }
    val results = remember(q, all.size) {
        if (q.trim().length < 2) emptyList()
        else all.filter { it.name.contains(q.trim(), ignoreCase = true) }
            .distinctBy { it.kind to it.id }.take(150)
    }

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        OutlinedTextField(
            q, { q = it }, singleLine = true,
            placeholder = { Text("Buscar canais, filmes e séries") },
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        )
        when {
            q.trim().length < 2 -> Hint(if (vm.loading) "Carregando listas…" else "Digite pelo menos 2 letras")
            results.isEmpty() -> Hint(if (vm.loading) "Carregando listas…" else "Nada encontrado")
            else -> LazyVerticalGrid(
                GridCells.Adaptive(150.dp),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(results) { Poster(it, vm.isFav(it), { vm.toggleFav(it) }) { vm.open(it) } }
            }
        }
    }
}

@Composable
fun MyListScreen(vm: AppViewModel) {
    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        Text(
            "Minha lista", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp)
        )
        Text(
            "Toque no ♥ de qualquer item para adicionar ou remover",
            color = Color.Gray, fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        if (vm.favorites.isEmpty()) Hint("Sua lista está vazia")
        else LazyVerticalGrid(
            GridCells.Adaptive(150.dp),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(vm.favorites.toList()) { Poster(it, vm.isFav(it), { vm.toggleFav(it) }) { vm.open(it) } }
        }
    }
}

@Composable
private fun Hint(text: String) {
    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Color.Gray)
    }
}
