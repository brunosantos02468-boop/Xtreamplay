package com.example.xtreamplay

import android.app.Application
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private val kidsRegex = Regex(
    "infantil|kids|crian|desenho|cartoon|anima|fam[ií]lia|disney|nick|gloob|baby|boomerang|junior|toon",
    RegexOption.IGNORE_CASE
)
private val adultRegex = Regex(
    "adult|xxx|porn|er[oó]tic|\\+18|18\\+|sexo|hentai|playboy|brazzers",
    RegexOption.IGNORE_CASE
)

private fun itemJson(i: Item) = JSONObject()
    .put("id", i.id).put("name", i.name).put("image", i.image ?: "")
    .put("category", i.category).put("kind", i.kind.name).put("ext", i.ext)

private fun jsonItem(o: JSONObject) = Item(
    o.getString("id"), o.getString("name"), o.optString("image").ifBlank { null },
    o.optString("category"), Kind.valueOf(o.getString("kind")), o.optString("ext")
)

@Stable
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("session", 0)
    private val cacheDir = app.cacheDir
    private var pending = 0
    private var api: XtreamApi? = null

    var creds by mutableStateOf<Credentials?>(null); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var tab by mutableStateOf(Kind.LIVE); private set
    val shelves = mutableStateMapOf<Kind, List<Shelf>>()
    val derived = mutableStateMapOf<Kind, Derived>()
    var playing by mutableStateOf<Play?>(null)
    var screen by mutableStateOf(Screen.HOME)

    // Detalhes do título
    var detail by mutableStateOf<Item?>(null); private set
    var detailInfo by mutableStateOf<Details?>(null); private set
    var episodes by mutableStateOf<List<Episode>>(emptyList()); private set

    // Perfis, favoritos e "continuar assistindo" (cada perfil tem os seus)
    val profiles = mutableStateListOf<Profile>()
    var profile by mutableStateOf<Profile?>(null); private set
    val favorites = mutableStateListOf<Item>()
    val recent = mutableStateListOf<Recent>()

    // Configurações
    var liveFormat by mutableStateOf(prefs.getString("liveFormat", "m3u8") ?: "m3u8"); private set
    var resizeMode by mutableStateOf(prefs.getInt("resize", 0)); private set
    var autoFullscreen by mutableStateOf(prefs.getBoolean("autoFs", true)); private set
    var hideAdult by mutableStateOf(prefs.getBoolean("hideAdult", true)); private set

    init {
        ensureProfiles()
        val s = prefs.getString("server", null)
        val u = prefs.getString("user", null)
        val p = prefs.getString("pass", null)
        if (s != null && u != null && p != null) {
            val c = Credentials(s, u, p)
            creds = c
            api = XtreamApi(c, cacheDir)
            loadTab(Kind.LIVE)
        }
    }

    fun updateLiveFormat(v: String) { liveFormat = v; prefs.edit().putString("liveFormat", v).apply() }
    fun updateResizeMode(v: Int) { resizeMode = v; prefs.edit().putInt("resize", v).apply() }
    fun updateAutoFullscreen(v: Boolean) { autoFullscreen = v; prefs.edit().putBoolean("autoFs", v).apply() }
    fun updateHideAdult(v: Boolean) { hideAdult = v; prefs.edit().putBoolean("hideAdult", v).apply(); rebuildAll() }

    /* ---------- Filtros (calculados fora da tela principal e guardados) ---------- */

    private suspend fun derive(k: Kind, src: List<Shelf>, kids: Boolean, hide: Boolean): Derived =
        withContext(Dispatchers.Default) {
            val vis = when {
                kids -> src.filter { kidsRegex.containsMatchIn(it.title) && !adultRegex.containsMatchIn(it.title) }
                hide -> src.filter { !adultRegex.containsMatchIn(it.title) }
                else -> src
            }
            val items = vis.flatMap { it.items }
            val top = if (k == Kind.LIVE) emptyList()
            else items.filter { it.rating > 0 }.sortedByDescending { it.rating }.take(10)
            val news = if (k == Kind.LIVE) emptyList()
            else items.sortedByDescending { it.added }.take(40)
            Derived(vis, items, top, news)
        }

    private fun rebuildAll() {
        val kids = profile?.kids == true
        val hide = hideAdult
        viewModelScope.launch {
            Kind.values().forEach { k ->
                shelves[k]?.let { derived[k] = derive(k, it, kids, hide) }
            }
        }
    }

    fun visible(k: Kind): List<Shelf> = derived[k]?.shelves.orEmpty()
    fun visibleItems(k: Kind): List<Item> = derived[k]?.items.orEmpty()
    fun top10(k: Kind): List<Item> = derived[k]?.top10.orEmpty()
    fun news(k: Kind): List<Item> = derived[k]?.news.orEmpty()

    fun similar(item: Item): List<Item> =
        visibleItems(item.kind).filter { it.category == item.category && it.id != item.id }.take(20)

    /* ---------- Perfis ---------- */

    private fun ensureProfiles() {
        if (profiles.isEmpty()) {
            runCatching {
                val arr = JSONArray(prefs.getString("profiles", "[]"))
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    profiles += Profile(
                        o.getString("id"), o.getString("name"), o.optInt("color"),
                        o.optBoolean("kids"), o.optString("pin")
                    )
                }
            }
        }
        if (profiles.isEmpty()) {
            profiles += Profile("p1", "Perfil 1", 0)
            saveProfiles()
        }
    }

    private fun saveProfiles() {
        val arr = JSONArray()
        profiles.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name).put("color", it.color)
                    .put("kids", it.kids).put("pin", it.pin)
            )
        }
        prefs.edit().putString("profiles", arr.toString()).apply()
    }

    fun selectProfile(p: Profile) {
        profile = p
        screen = Screen.HOME
        detail = null
        rebuildAll()
        loadFavs()
        loadRecent()
    }

    fun switchProfile() { profile = null; detail = null }

    fun addProfile(name: String, kids: Boolean) {
        if (name.isBlank() || profiles.size >= 5) return
        profiles += Profile(System.currentTimeMillis().toString(), name.trim(), profiles.size, kids)
        saveProfiles()
    }

    fun deleteProfile(p: Profile) {
        if (profiles.size <= 1) return
        profiles.remove(p)
        prefs.edit().remove("favs_${p.id}").remove("recent_${p.id}").apply()
        saveProfiles()
    }

    /** PIN de 4 dígitos do perfil ativo; vazio remove o PIN. */
    fun setPin(pin: String) {
        val p = profile ?: return
        val np = p.copy(pin = pin)
        val i = profiles.indexOfFirst { it.id == p.id }
        if (i >= 0) profiles[i] = np
        profile = np
        saveProfiles()
    }

    /* ---------- Login / sessão ---------- */

    private fun normalize(server: String): String {
        var s = server.trim().trimEnd('/')
        if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://$s"
        return s
    }

    fun login(server: String, user: String, pass: String) {
        if (server.isBlank() || user.isBlank() || pass.isBlank()) {
            error = "Preencha servidor, usuário e senha"; return
        }
        viewModelScope.launch {
            loading = true; error = null
            try {
                val c = Credentials(normalize(server), user.trim(), pass.trim())
                val a = XtreamApi(c, cacheDir)
                a.login()
                prefs.edit().putString("server", c.server).putString("user", c.user)
                    .putString("pass", c.pass).apply()
                api = a; creds = c
                shelves.clear()
                ensureProfiles()
                profile = null
                screen = Screen.HOME
                loadTab(Kind.LIVE)
            } catch (e: Exception) {
                error = e.message ?: "Falha ao conectar"
            } finally { loading = pending > 0 }
        }
    }

    fun logout() {
        val ed = prefs.edit()
        profiles.forEach { ed.remove("favs_${it.id}").remove("recent_${it.id}") }
        ed.remove("server").remove("user").remove("pass").remove("profiles").remove("favs").apply()
        profiles.clear(); profile = null
        favorites.clear(); recent.clear()
        creds = null; api?.clearCache(); api = null; shelves.clear(); derived.clear(); playing = null; detail = null
        screen = Screen.HOME; error = null
        ensureProfiles()
    }

    fun refresh() {
        api?.clearCache()
        shelves.clear(); derived.clear()
        loadTab(tab)
    }

    fun selectTab(k: Kind) {
        tab = k
        if (shelves[k] == null) loadTab(k)
    }

    fun go(s: Screen) {
        screen = s
        when (s) {
            Screen.SEARCH -> Kind.values().forEach { if (shelves[it] == null) loadTab(it) }
            Screen.NEWS -> listOf(Kind.MOVIE, Kind.SERIES).forEach { if (shelves[it] == null) loadTab(it) }
            else -> {}
        }
    }

    private fun loadTab(k: Kind) {
        val a = api ?: return
        viewModelScope.launch {
            pending++; loading = true; error = null
            try {
                val list = a.shelves(k)
                derived[k] = derive(k, list, profile?.kids == true, hideAdult)
                shelves[k] = list
            } catch (e: Exception) {
                error = e.message ?: "Erro ao carregar lista"
            } finally {
                pending--; loading = pending > 0
            }
        }
    }

    /* ---------- Abrir / reproduzir ---------- */

    /** Toque num título: canais tocam direto; filmes e séries abrem os detalhes. */
    fun open(item: Item) {
        if (item.kind == Kind.LIVE) playLive(item) else openDetail(item)
    }

    /** Botão "Assistir" do banner. */
    fun playNow(item: Item) {
        when (item.kind) {
            Kind.LIVE -> playLive(item)
            Kind.MOVIE -> playMovie(item)
            Kind.SERIES -> openDetail(item)
        }
    }

    private fun playLive(item: Item) {
        val a = api ?: return
        playing = Play(a.liveUrl(item.id, liveFormat), item.name)
    }

    fun playMovie(item: Item) {
        val a = api ?: return
        val url = a.movieUrl(item.id, item.ext)
        playing = Play(url, item.name, item, recent.firstOrNull { it.url == url }?.positionMs ?: 0)
    }

    fun openDetail(item: Item) {
        val a = api ?: return
        detail = item; detailInfo = null; episodes = emptyList()
        viewModelScope.launch {
            try {
                if (item.kind == Kind.SERIES) {
                    val (d, ep) = a.seriesInfo(item.id)
                    if (detail?.id == item.id) { detailInfo = d; episodes = ep }
                } else {
                    val d = a.movieDetails(item.id)
                    if (detail?.id == item.id) detailInfo = d
                }
            } catch (e: Exception) {
                if (detail?.id == item.id) detailInfo = Details()
            }
        }
    }

    fun closeDetail() { detail = null }

    fun playEpisode(e: Episode) {
        val a = api ?: return
        val s = detail
        val url = a.episodeUrl(e.id, e.ext)
        val title = if (s != null) "${s.name} · ${e.title}" else e.title
        playing = Play(url, title, s, recent.firstOrNull { it.url == url }?.positionMs ?: 0)
    }

    /** Fim do episódio: toca o próximo; fim do filme: volta aos detalhes. */
    fun playNextEpisode() {
        val a = api ?: return
        val p = playing ?: return
        if (p.item == null) return
        val idx = episodes.indexOfFirst { a.episodeUrl(it.id, it.ext) == p.url }
        if (idx >= 0 && idx + 1 < episodes.size) playEpisode(episodes[idx + 1])
        else playing = null
    }

    /* ---------- Continuar assistindo ---------- */

    fun resume(r: Recent) {
        playing = Play(r.url, r.title, r.item, r.positionMs)
    }

    fun removeRecent(r: Recent) {
        recent.remove(r)
        saveRecent()
    }

    fun saveProgress(p: Play, pos: Long, dur: Long) {
        val item = p.item ?: return
        if (dur <= 0 || pos <= 5000) return
        recent.removeAll { it.item.id == item.id && it.item.kind == item.kind }
        if (pos < dur * 0.95) recent.add(0, Recent(item, p.url, p.title, pos, dur))
        while (recent.size > 20) recent.removeAt(recent.size - 1)
        saveRecent()
    }

    private fun loadRecent() {
        recent.clear()
        val id = profile?.id ?: return
        runCatching {
            val arr = JSONArray(prefs.getString("recent_$id", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                recent += Recent(jsonItem(o), o.getString("url"), o.getString("title"), o.getLong("pos"), o.getLong("dur"))
            }
        }
    }

    private fun saveRecent() {
        val id = profile?.id ?: return
        val arr = JSONArray()
        recent.forEach {
            arr.put(itemJson(it.item).put("url", it.url).put("title", it.title).put("pos", it.positionMs).put("dur", it.durationMs))
        }
        prefs.edit().putString("recent_$id", arr.toString()).apply()
    }

    /* ---------- Minha lista (favoritos) ---------- */

    private fun loadFavs() {
        favorites.clear()
        val p = profile ?: return
        runCatching {
            val raw = prefs.getString("favs_${p.id}", null)
                ?: (if (p.id == "p1") prefs.getString("favs", null) else null) ?: "[]"
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) favorites += jsonItem(arr.getJSONObject(i))
        }
    }

    private fun saveFavs() {
        val id = profile?.id ?: return
        val arr = JSONArray()
        favorites.forEach { arr.put(itemJson(it)) }
        prefs.edit().putString("favs_$id", arr.toString()).apply()
    }

    private val favKeys by derivedStateOf { favorites.mapTo(HashSet()) { "${it.kind}:${it.id}" } }

    fun isFav(i: Item) = "${i.kind}:${i.id}" in favKeys

    fun toggleFav(i: Item) {
        val ex = favorites.firstOrNull { it.id == i.id && it.kind == i.kind }
        if (ex != null) favorites.remove(ex) else favorites.add(0, i)
        saveFavs()
        android.widget.Toast.makeText(
            getApplication<Application>(),
            if (ex != null) "Removido da Minha lista" else "Adicionado à Minha lista",
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }
}

/** Listas já filtradas e ordenadas (calculadas uma vez, não a cada desenho da tela). */
class Derived(
    val shelves: List<Shelf>,
    val items: List<Item>,
    val top10: List<Item>,
    val news: List<Item>
)
