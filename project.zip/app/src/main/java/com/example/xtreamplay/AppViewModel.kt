package com.example.xtreamplay

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private fun itemJson(i: Item) = JSONObject()
    .put("id", i.id).put("name", i.name).put("image", i.image ?: "")
    .put("category", i.category).put("kind", i.kind.name).put("ext", i.ext)

private fun jsonItem(o: JSONObject) = Item(
    o.getString("id"), o.getString("name"), o.optString("image").ifBlank { null },
    o.optString("category"), Kind.valueOf(o.getString("kind")), o.optString("ext")
)

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("session", 0)
    private var api: XtreamApi? = null

    var creds by mutableStateOf<Credentials?>(null); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var tab by mutableStateOf(Kind.LIVE); private set
    val shelves = mutableStateMapOf<Kind, List<Shelf>>()
    var openSeries by mutableStateOf<Item?>(null); private set
    var episodes by mutableStateOf<List<Episode>>(emptyList()); private set
    var playing by mutableStateOf<Play?>(null)
    var screen by mutableStateOf(Screen.HOME)

    // Perfis, favoritos e "continuar assistindo" (cada perfil tem os seus)
    val profiles = mutableStateListOf<Profile>()
    var profile by mutableStateOf<Profile?>(null); private set
    val favorites = mutableStateListOf<Item>()
    val recent = mutableStateListOf<Recent>()

    // Configurações
    var liveFormat by mutableStateOf(prefs.getString("liveFormat", "m3u8") ?: "m3u8"); private set
    var resizeMode by mutableStateOf(prefs.getInt("resize", 0)); private set
    var autoFullscreen by mutableStateOf(prefs.getBoolean("autoFs", true)); private set

    init {
        ensureProfiles()
        val s = prefs.getString("server", null)
        val u = prefs.getString("user", null)
        val p = prefs.getString("pass", null)
        if (s != null && u != null && p != null) {
            val c = Credentials(s, u, p)
            creds = c
            api = XtreamApi(c)
            loadTab(Kind.LIVE)
        }
    }

    fun updateLiveFormat(v: String) { liveFormat = v; prefs.edit().putString("liveFormat", v).apply() }
    fun updateResizeMode(v: Int) { resizeMode = v; prefs.edit().putInt("resize", v).apply() }
    fun updateAutoFullscreen(v: Boolean) { autoFullscreen = v; prefs.edit().putBoolean("autoFs", v).apply() }

    /* ---------- Perfis ---------- */

    private fun ensureProfiles() {
        if (profiles.isEmpty()) {
            runCatching {
                val arr = JSONArray(prefs.getString("profiles", "[]"))
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    profiles += Profile(o.getString("id"), o.getString("name"), o.optInt("color"))
                }
            }
        }
        if (profiles.isEmpty()) {
            profiles += Profile("p1", "Perfil 1", 0)
            saveProfiles()
        }
    }

    private fun saveProfiles() {
        val arr = JSONArray()
        profiles.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("color", it.color)) }
        prefs.edit().putString("profiles", arr.toString()).apply()
    }

    fun selectProfile(p: Profile) {
        profile = p
        screen = Screen.HOME
        loadFavs()
        loadRecent()
    }

    fun switchProfile() { profile = null }

    fun addProfile(name: String) {
        if (name.isBlank() || profiles.size >= 5) return
        profiles += Profile(System.currentTimeMillis().toString(), name.trim(), profiles.size)
        saveProfiles()
    }

    fun deleteProfile(p: Profile) {
        if (profiles.size <= 1) return
        profiles.remove(p)
        prefs.edit().remove("favs_${p.id}").remove("recent_${p.id}").apply()
        saveProfiles()
    }

    /* ---------- Login / sessão ---------- */

    private fun normalize(server: String): String {
        var s = server.trim().trimEnd('/')
        if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://$s"
        return s
    }

    fun login(server: String, user: String, pass: String) {
        if (server.isBlank() || user.isBlank() || pass.isBlank()) {
            error = "Preencha servidor, usuário e senha"; return
        }
        viewModelScope.launch {
            loading = true; error = null
            try {
                val c = Credentials(normalize(server), user.trim(), pass.trim())
                val a = XtreamApi(c)
                a.login()
                prefs.edit().putString("server", c.server).putString("user", c.user)
                    .putString("pass", c.pass).apply()
                api = a; creds = c
                shelves.clear()
                ensureProfiles()
                profile = null
                screen = Screen.HOME
                loadTab(Kind.LIVE)
            } catch (e: Exception) {
                error = e.message ?: "Falha ao conectar"
            } finally { loading = false }
        }
    }

    fun logout() {
        val ed = prefs.edit()
        profiles.forEach { ed.remove("favs_${it.id}").remove("recent_${it.id}") }
        ed.remove("server").remove("user").remove("pass").remove("profiles").remove("favs").apply()
        profiles.clear(); profile = null
        favorites.clear(); recent.clear()
        creds = null; api = null; shelves.clear(); playing = null; openSeries = null
        screen = Screen.HOME; error = null
        ensureProfiles()
    }

    fun refresh() {
        shelves.clear()
        loadTab(tab)
    }

    fun selectTab(k: Kind) {
        tab = k
        if (shelves[k] == null) loadTab(k)
    }

    fun go(s: Screen) {
        screen = s
        if (s == Screen.SEARCH) Kind.values().forEach { if (shelves[it] == null) loadTab(it) }
    }

    private fun loadTab(k: Kind) {
        val a = api ?: return
        viewModelScope.launch {
            loading = true; error = null
            try { shelves[k] = a.shelves(k) }
            catch (e: Exception) { error = e.message ?: "Erro ao carregar lista" }
            finally { loading = false }
        }
    }

    /* ---------- Reprodução ---------- */

    fun open(item: Item) {
        val a = api ?: return
        when (item.kind) {
            Kind.LIVE -> playing = Play(a.liveUrl(item.id, liveFormat), item.name)
            Kind.MOVIE -> {
                val url = a.movieUrl(item.id, item.ext)
                playing = Play(url, item.name, item, recent.firstOrNull { it.url == url }?.positionMs ?: 0)
            }
            Kind.SERIES -> {
                openSeries = item; episodes = emptyList()
                viewModelScope.launch {
                    try { episodes = a.episodes(item.id) }
                    catch (e: Exception) { error = e.message }
                }
            }
        }
    }

    fun playEpisode(e: Episode) {
        val a = api ?: return
        val s = openSeries
        val url = a.episodeUrl(e.id, e.ext)
        val title = if (s != null) "${s.name} · ${e.title}" else e.title
        playing = Play(url, title, s, recent.firstOrNull { it.url == url }?.positionMs ?: 0)
        openSeries = null
    }

    fun closeSeries() { openSeries = null }

    /* ---------- Continuar assistindo ---------- */

    fun resume(r: Recent) {
        playing = Play(r.url, r.title, r.item, r.positionMs)
    }

    fun removeRecent(r: Recent) {
        recent.remove(r)
        saveRecent()
    }

    fun saveProgress(p: Play, pos: Long, dur: Long) {
        val item = p.item ?: return
        if (dur <= 0 || pos <= 5000) return
        recent.removeAll { it.item.id == item.id && it.item.kind == item.kind }
        if (pos < dur * 0.95) recent.add(0, Recent(item, p.url, p.title, pos, dur))
        while (recent.size > 20) recent.removeAt(recent.size - 1)
        saveRecent()
    }

    private fun loadRecent() {
        recent.clear()
        val id = profile?.id ?: return
        runCatching {
            val arr = JSONArray(prefs.getString("recent_$id", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                recent += Recent(jsonItem(o), o.getString("url"), o.getString("title"), o.getLong("pos"), o.getLong("dur"))
            }
        }
    }

    private fun saveRecent() {
        val id = profile?.id ?: return
        val arr = JSONArray()
        recent.forEach {
            arr.put(itemJson(it.item).put("url", it.url).put("title", it.title).put("pos", it.positionMs).put("dur", it.durationMs))
        }
        prefs.edit().putString("recent_$id", arr.toString()).apply()
    }

    /* ---------- Minha lista (favoritos) ---------- */

    private fun loadFavs() {
        favorites.clear()
        val p = profile ?: return
        runCatching {
            val raw = prefs.getString("favs_${p.id}", null)
                ?: (if (p.id == "p1") prefs.getString("favs", null) else null) ?: "[]"
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) favorites += jsonItem(arr.getJSONObject(i))
        }
    }

    private fun saveFavs() {
        val id = profile?.id ?: return
        val arr = JSONArray()
        favorites.forEach { arr.put(itemJson(it)) }
        prefs.edit().putString("favs_$id", arr.toString()).apply()
    }

    fun isFav(i: Item) = favorites.any { it.id == i.id && it.kind == i.kind }

    fun toggleFav(i: Item) {
        val ex = favorites.firstOrNull { it.id == i.id && it.kind == i.kind }
        if (ex != null) favorites.remove(ex) else favorites.add(0, i)
        saveFavs()
    }
}
