package com.example.xtreamplay

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("session", 0)
    private var api: XtreamApi? = null

    var creds by mutableStateOf<Credentials?>(null); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var tab by mutableStateOf(Kind.LIVE); private set
    val shelves = mutableStateMapOf<Kind, List<Shelf>>()
    var openSeries by mutableStateOf<Item?>(null); private set
    var episodes by mutableStateOf<List<Episode>>(emptyList()); private set
    var playing by mutableStateOf<Play?>(null)

    init {
        val s = prefs.getString("server", null)
        val u = prefs.getString("user", null)
        val p = prefs.getString("pass", null)
        if (s != null && u != null && p != null) {
            val c = Credentials(s, u, p)
            creds = c
            api = XtreamApi(c)
            loadTab(Kind.LIVE)
        }
    }

    private fun normalize(server: String): String {
        var s = server.trim().trimEnd('/')
        if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://$s"
        return s
    }

    fun login(server: String, user: String, pass: String) {
        if (server.isBlank() || user.isBlank() || pass.isBlank()) {
            error = "Preencha servidor, usuário e senha"; return
        }
        viewModelScope.launch {
            loading = true; error = null
            try {
                val c = Credentials(normalize(server), user.trim(), pass.trim())
                val a = XtreamApi(c)
                a.login()
                prefs.edit().putString("server", c.server).putString("user", c.user)
                    .putString("pass", c.pass).apply()
                api = a; creds = c
                shelves.clear()
                loadTab(Kind.LIVE)
            } catch (e: Exception) {
                error = e.message ?: "Falha ao conectar"
            } finally { loading = false }
        }
    }

    fun logout() {
        prefs.edit().clear().apply()
        creds = null; api = null; shelves.clear(); playing = null; openSeries = null
    }

    fun selectTab(k: Kind) {
        tab = k
        if (shelves[k] == null) loadTab(k)
    }

    private fun loadTab(k: Kind) {
        val a = api ?: return
        viewModelScope.launch {
            loading = true; error = null
            try { shelves[k] = a.shelves(k) }
            catch (e: Exception) { error = e.message ?: "Erro ao carregar lista" }
            finally { loading = false }
        }
    }

    fun open(item: Item) {
        val a = api ?: return
        when (item.kind) {
            Kind.LIVE -> playing = Play(a.liveUrl(item.id), item.name)
            Kind.MOVIE -> playing = Play(a.movieUrl(item.id, item.ext), item.name)
            Kind.SERIES -> {
                openSeries = item; episodes = emptyList()
                viewModelScope.launch {
                    try { episodes = a.episodes(item.id) }
                    catch (e: Exception) { error = e.message }
                }
            }
        }
    }

    fun playEpisode(e: Episode) {
        val a = api ?: return
        playing = Play(a.episodeUrl(e.id, e.ext), e.title)
        openSeries = null
    }

    fun closeSeries() { openSeries = null }
}
