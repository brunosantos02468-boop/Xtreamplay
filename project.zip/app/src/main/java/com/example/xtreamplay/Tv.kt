package com.example.xtreamplay

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.focus.focusRestorer
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/** true quando o app roda em uma TV (Google TV / Android TV). */
val LocalIsTv = staticCompositionLocalOf { false }

fun detectTv(ctx: Context): Boolean {
    val ui = ctx.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
    return ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
        ctx.packageManager.hasSystemFeature("android.software.leanback")
}

/** Moldura branca + leve aumento no item selecionado pelo controle remoto (só na TV). Leve: não recompõe a tela. */
fun Modifier.tvFocusRing(shape: Shape = RoundedCornerShape(8.dp)): Modifier = composed {
    if (!LocalIsTv.current) Modifier
    else {
        val focused = remember { mutableStateOf(false) }
        Modifier
            .onFocusChanged { focused.value = it.hasFocus }
            .graphicsLayer {
                val sc = if (focused.value) 1.08f else 1f
                scaleX = sc; scaleY = sc
            }
            .drawWithContent {
                drawContent()
                if (focused.value) {
                    val stroke = 3.dp.toPx()
                    val outline = shape.createOutline(
                        Size(size.width - stroke, size.height - stroke), layoutDirection, this
                    )
                    translate(stroke / 2f, stroke / 2f) {
                        drawOutline(outline, Color.White, style = Stroke(stroke))
                    }
                }
            }
    }
}

fun Modifier.tvClickable(shape: Shape = RoundedCornerShape(8.dp), onClick: () -> Unit): Modifier =
    this.tvFocusRing(shape).clickable(onClick = onClick)

/**
 * Na TV: OK rápido = clicar; OK segurado por ~0,5 s = ação longa (favoritar, remover etc.).
 * Mede o tempo entre apertar e soltar, então funciona mesmo em controles que não repetem a tecla.
 */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.tvCombinedClickable(
    shape: Shape = RoundedCornerShape(8.dp),
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
): Modifier = composed {
    if (!LocalIsTv.current) Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick)
    else {
        val click by rememberUpdatedState(onClick)
        val long by rememberUpdatedState(onLongClick)
        val st = remember { LongArray(2) } // [0] = instante em que apertou, [1] = ação longa já disparada
        Modifier
            .tvFocusRing(shape)
            .onPreviewKeyEvent { e ->
                val k = e.key
                if (k != Key.DirectionCenter && k != Key.Enter && k != Key.NumPadEnter) return@onPreviewKeyEvent false
                val t = e.nativeKeyEvent.eventTime
                when (e.type) {
                    KeyEventType.KeyDown -> {
                        if (st[0] == 0L) { st[0] = t; st[1] = 0L }
                        else if (st[1] == 0L && long != null && t - st[0] >= 500L) { st[1] = 1L; long?.invoke() }
                        true
                    }
                    KeyEventType.KeyUp -> {
                        val had = st[0] != 0L
                        val fired = st[1] == 1L
                        val held = t - st[0]
                        st[0] = 0L; st[1] = 0L
                        if (had && !fired) {
                            if (long != null && held >= 500L) long?.invoke() else click()
                        }
                        true
                    }
                    else -> false
                }
            }
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    }
}

/**
 * Na TV, a caixa de texto NÃO abre o teclado ao receber o foco (para dar para navegar
 * pelos menus com as setas). O teclado só abre quando você aperta o OK/Enter em cima dela.
 */
@OptIn(ExperimentalComposeUiApi::class)
fun Modifier.tvKeyboardOnOk(): Modifier = composed {
    if (!LocalIsTv.current) Modifier
    else {
        val keyboard = LocalSoftwareKeyboardController.current
        var focused by remember { mutableStateOf(false) }
        var openedByUser by remember { mutableStateOf(false) }
        LaunchedEffect(focused) {
            openedByUser = false
            if (focused) {
                // o sistema tenta abrir o teclado sozinho; fecha de novo enquanto você não apertar OK
                for (wait in longArrayOf(0, 120, 350)) {
                    delay(wait)
                    if (openedByUser) break
                    keyboard?.hide()
                }
            }
        }
        Modifier
            .onFocusChanged { focused = it.isFocused }
            .onPreviewKeyEvent { e ->
                val ok = e.key == Key.DirectionCenter || e.key == Key.Enter || e.key == Key.NumPadEnter
                if (ok && e.type == KeyEventType.KeyDown) {
                    openedByUser = true
                    keyboard?.show()
                    true
                } else false
            }
    }
}

/** Ao voltar para uma fileira/menu, o foco retorna ao último item em que você estava. */
@OptIn(ExperimentalComposeUiApi::class)
fun Modifier.tvRestorer(): Modifier = this.focusRestorer()

/**
 * Rede de segurança para o controle remoto: se nenhum item do app estiver com foco
 * (acontece ao trocar de tela), a primeira seta apertada só "acorda" o foco.
 */
object TvFocus {
    @Volatile var hasFocus: Boolean = false
    @Volatile var lastKickAt: Long = 0L
    var kick by mutableIntStateOf(0)
}
