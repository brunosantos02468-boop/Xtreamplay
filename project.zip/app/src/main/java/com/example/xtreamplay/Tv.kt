package com.example.xtreamplay

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay

/** true quando o app roda em uma TV (Google TV / Android TV). */
val LocalIsTv = staticCompositionLocalOf { false }

fun detectTv(ctx: Context): Boolean {
    val ui = ctx.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
    return ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
        ctx.packageManager.hasSystemFeature("android.software.leanback")
}

/** Moldura branca + leve aumento no item selecionado pelo controle remoto (só na TV). */
fun Modifier.tvFocusRing(shape: Shape = RoundedCornerShape(8.dp)): Modifier = composed {
    if (!LocalIsTv.current) Modifier
    else {
        var focused by remember { mutableStateOf(false) }
        val scale by animateFloatAsState(if (focused) 1.06f else 1f, label = "tvFocusScale")
        Modifier
            .onFocusChanged { focused = it.hasFocus }
            .zIndex(if (focused) 1f else 0f)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .then(if (focused) Modifier.border(3.dp, Color.White, shape) else Modifier)
    }
}

fun Modifier.tvClickable(shape: Shape = RoundedCornerShape(8.dp), onClick: () -> Unit): Modifier =
    this.tvFocusRing(shape).clickable(onClick = onClick)

@OptIn(ExperimentalFoundationApi::class)
fun Modifier.tvCombinedClickable(
    shape: Shape = RoundedCornerShape(8.dp),
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
): Modifier = this.tvFocusRing(shape).combinedClickable(onClick = onClick, onLongClick = onLongClick)

/**
 * Na TV, a caixa de texto NÃO abre o teclado ao receber o foco (para dar para navegar
 * pelos menus com as setas). O teclado só abre quando você aperta o OK/Enter em cima dela.
 */
@OptIn(ExperimentalComposeUiApi::class)
fun Modifier.tvKeyboardOnOk(): Modifier = composed {
    if (!LocalIsTv.current) Modifier
    else {
        val keyboard = LocalSoftwareKeyboardController.current
        var focused by remember { mutableStateOf(false) }
        var openedByUser by remember { mutableStateOf(false) }
        LaunchedEffect(focused) {
            openedByUser = false
            if (focused) {
                // o sistema tenta abrir o teclado sozinho; fecha de novo enquanto você não apertar OK
                for (wait in longArrayOf(0, 120, 350)) {
                    delay(wait)
                    if (openedByUser) break
                    keyboard?.hide()
                }
            }
        }
        Modifier
            .onFocusChanged { focused = it.isFocused }
            .onPreviewKeyEvent { e ->
                val ok = e.key == Key.DirectionCenter || e.key == Key.Enter || e.key == Key.NumPadEnter
                if (ok && e.type == KeyEventType.KeyDown) {
                    openedByUser = true
                    keyboard?.show()
                    true
                } else false
            }
    }
}
