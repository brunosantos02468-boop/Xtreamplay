package com.example.xtreamplay

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp

/** Logo do Prisma: um feixe de luz entra no prisma e sai separado em cores. */
@Composable
fun PrismaLogo(logoSize: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(logoSize)) {
        val w = size.width
        val h = size.height
        fun p(x: Float, y: Float) = Offset(x * w, y * h)
        val sw = w * 0.035f

        // feixe de entrada
        drawLine(Color.White, p(0.02f, 0.64f), p(0.30f, 0.57f), strokeWidth = sw, cap = StrokeCap.Round)

        // prisma
        val tri = Path().apply {
            moveTo(0.50f * w, 0.14f * h)
            lineTo(0.80f * w, 0.78f * h)
            lineTo(0.20f * w, 0.78f * h)
            close()
        }
        drawPath(tri, Color(0x33FFFFFF))
        drawPath(tri, Color.White, style = Stroke(width = sw, join = StrokeJoin.Round))

        // luz dentro do prisma
        drawLine(Color(0x99FFFFFF), p(0.30f, 0.57f), p(0.70f, 0.59f), strokeWidth = sw * 0.7f, cap = StrokeCap.Round)

        // espectro
        val colors = listOf(
            Color(0xFFFF3B30), Color(0xFFFF9500), Color(0xFFFFD60A),
            Color(0xFF34C759), Color(0xFF0A84FF), Color(0xFFBF5AF2)
        )
        colors.forEachIndexed { i, c ->
            drawLine(c, p(0.70f, 0.59f), p(0.99f, 0.36f + i * 0.09f), strokeWidth = sw, cap = StrokeCap.Round)
        }
    }
}
