package com.example.xtreamplay

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

@Composable
fun PlayerScreen(play: Play, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }
    var err by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(play.url) {
        err = null
        player.setMediaItem(MediaItem.fromUri(play.url))
        player.prepare()
        player.playWhenReady = true
    }
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                err = "Não foi possível reproduzir (${error.errorCodeName})"
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }
    BackHandler(onBack = onBack)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { PlayerView(it).apply { this.player = player; keepScreenOn = true } },
            modifier = Modifier.fillMaxSize()
        )
        TextButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).statusBarsPadding()) {
            Text("←  ${play.title}", color = Color.White)
        }
        err?.let { Text(it, color = Color(0xFFFF6B6B), modifier = Modifier.align(Alignment.Center).padding(24.dp)) }
    }
}
