package com.example.xtreamplay

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.os.Build
import android.util.Rational
import android.view.View
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.focusable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.util.Locale

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Picture-in-picture (janela flutuante). */
fun enterPip(a: Activity?) {
    if (a != null && Build.VERSION.SDK_INT >= 26) {
        runCatching {
            a.enterPictureInPictureMode(
                PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
            )
        }
    }
}

private val resizeLabels = listOf("Ajustar", "Preencher", "Zoom")

@OptIn(UnstableApi::class)
private fun resizeConst(i: Int) = when (i) {
    1 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
    2 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    play: Play, initialResize: Int, startFullscreen: Boolean,
    onProgress: (Long, Long) -> Unit, onEnded: () -> Unit, onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val activity = remember { ctx.findActivity() }
    val isTv = LocalIsTv.current
    val rootFocus = remember { FocusRequester() }
    val topFocus = remember { FocusRequester() }
    var rootFocused by remember { mutableStateOf(false) }
    var focusTopTick by remember { mutableIntStateOf(0) }
    var pv by remember { mutableStateOf<PlayerView?>(null) }
    val player = remember {
        // Muitos servidores IPTV bloqueiam o User-Agent padrão do ExoPlayer e redirecionam
        // entre http/https. Por isso usamos um User-Agent comum e liberamos esses redirecionamentos.
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(20_000)
            .setReadTimeoutMs(30_000)
        ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(ctx).setDataSourceFactory(http))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
    }
    val progress by rememberUpdatedState(onProgress)
    val ended by rememberUpdatedState(onEnded)

    var err by remember { mutableStateOf<String?>(null) }
    var fullscreen by remember { mutableStateOf(startFullscreen) }
    var resize by remember { mutableStateOf(initialResize) }
    var controls by remember { mutableStateOf(true) }
    var tracks by remember { mutableStateOf(Tracks.EMPTY) }
    var showTracks by remember { mutableStateOf(false) }

    LaunchedEffect(play.url) {
        err = null
        player.setMediaItem(MediaItem.fromUri(play.url), play.startMs)
        player.prepare()
        player.playWhenReady = true
    }

    // Salva o progresso a cada 5 s (continuar assistindo)
    LaunchedEffect(play.url) {
        while (true) {
            delay(5000)
            if (player.isPlaying) progress(player.currentPosition, player.duration)
        }
    }

    // Tela cheia imersiva (barras do sistema ocultas + horizontal)
    LaunchedEffect(fullscreen) {
        val a = activity ?: return@LaunchedEffect
        val ctl = WindowCompat.getInsetsController(a.window, a.window.decorView)
        if (fullscreen) {
            a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctl.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ctl.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val http = error.cause as? HttpDataSource.InvalidResponseCodeException
                err = if (http != null)
                    "Servidor recusou o vídeo (HTTP ${http.responseCode})"
                else
                    "Não foi possível reproduzir (${error.errorCodeName})"
            }
            override fun onTracksChanged(t: Tracks) { tracks = t }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    val d = player.duration
                    if (d > 0) progress(d, d)
                    ended()
                }
            }
        }
        player.addListener(l)
        onDispose {
            runCatching { progress(player.currentPosition, player.duration) }
            player.removeListener(l)
            player.release()
            activity?.let { a ->
                a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.getInsetsController(a.window, a.window.decorView)
                    .show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }
    BackHandler(onBack = onBack)

    // TV: o foco começa no próprio player (setas controlam o vídeo)
    LaunchedEffect(Unit) { if (isTv) runCatching { rootFocus.requestFocus() } }
    LaunchedEffect(controls) { if (isTv && !controls) runCatching { rootFocus.requestFocus() } }
    LaunchedEffect(focusTopTick) {
        if (focusTopTick > 0) { delay(80); runCatching { topFocus.requestFocus() } }
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .onKeyEvent { e ->
                if (!isTv || !rootFocused || e.type != KeyEventType.KeyDown) return@onKeyEvent false
                when (e.key) {
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.MediaPlayPause -> {
                        if (player.isPlaying) player.pause() else player.play()
                        pv?.showController(); true
                    }
                    Key.MediaPlay -> { player.play(); pv?.showController(); true }
                    Key.MediaPause -> { player.pause(); pv?.showController(); true }
                    Key.DirectionLeft, Key.MediaRewind -> { player.seekBack(); pv?.showController(); true }
                    Key.DirectionRight, Key.MediaFastForward -> { player.seekForward(); pv?.showController(); true }
                    Key.DirectionDown -> { pv?.showController(); true }
                    Key.DirectionUp -> { controls = true; pv?.showController(); focusTopTick++; true }
                    else -> false
                }
            }
            .focusRequester(rootFocus)
            .onFocusChanged { rootFocused = it.isFocused }
            .focusable()
    ) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    keepScreenOn = true
                    isFocusable = false
                    isFocusableInTouchMode = false
                    descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
                    pv = this
                    setControllerVisibilityListener(
                        PlayerView.ControllerVisibilityListener { v -> controls = v == View.VISIBLE }
                    )
                }
            },
            update = { it.resizeMode = resizeConst(resize) },
            modifier = Modifier.fillMaxSize()
        )

        AnimatedVisibility(controls, Modifier.align(Alignment.TopCenter)) {
            Row(
                Modifier.fillMaxWidth()
                    .onKeyEvent { e ->
                        if (isTv && e.type == KeyEventType.KeyDown && e.key == Key.DirectionDown) {
                            runCatching { rootFocus.requestFocus() }; true
                        } else false
                    }
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                    .statusBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onBack, modifier = Modifier.tvFocusRing(RoundedCornerShape(50)).focusRequester(topFocus)) { Text("←", color = Color.White, fontSize = 24.sp) }
                Text(
                    play.title, color = Color.White, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { showTracks = true }, modifier = Modifier.tvFocusRing(RoundedCornerShape(50))) { Text("Áudio/Leg.", color = Color.White) }
                if (!isTv) TextButton(onClick = { enterPip(activity) }) { Text("PiP", color = Color.White) }
                TextButton(onClick = { resize = (resize + 1) % 3 }, modifier = Modifier.tvFocusRing(RoundedCornerShape(50))) {
                    Text(resizeLabels[resize], color = Color.White)
                }
                TextButton(onClick = { fullscreen = !fullscreen }, modifier = Modifier.tvFocusRing(RoundedCornerShape(50))) {
                    Text(if (fullscreen) "Sair da tela cheia" else "Tela cheia", color = Color.White)
                }
            }
        }

        err?.let {
            Text(it, color = Color(0xFFFF6B6B), modifier = Modifier.align(Alignment.Center).padding(24.dp))
        }
    }

    if (showTracks) TracksDialog(player, tracks) { showTracks = false }
}

private fun trackLabel(g: Tracks.Group, i: Int): String {
    val f = g.getTrackFormat(i)
    val lang = f.language?.let { Locale(it).displayLanguage }?.takeIf { it.isNotBlank() }
    return f.label ?: lang ?: "Faixa ${i + 1}"
}

@Composable
private fun TracksDialog(player: ExoPlayer, tracks: Tracks, onClose: () -> Unit) {
    val audio = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
    val text = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
    val textDisabled = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
    val anyTextSelected = text.any { g -> (0 until g.length).any { g.isTrackSelected(it) } }

    fun pick(g: Tracks.Group, i: Int) {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(g.type, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
            .build()
        onClose()
    }

    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color(0xFF141414),
        title = { Text("Áudio e legendas", color = Color.White) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("ÁUDIO", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                if (audio.isEmpty()) Text("Faixa padrão", color = Color.LightGray, modifier = Modifier.padding(vertical = 8.dp))
                audio.forEach { g ->
                    for (i in 0 until g.length) TrackRow(trackLabel(g, i), g.isTrackSelected(i)) { pick(g, i) }
                }
                Spacer(Modifier.height(12.dp))
                Text("LEGENDAS", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                TrackRow("Desativadas", textDisabled || !anyTextSelected) {
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                    onClose()
                }
                text.forEach { g ->
                    for (i in 0 until g.length) TrackRow(trackLabel(g, i), !textDisabled && g.isTrackSelected(i)) { pick(g, i) }
                }
                if (text.isEmpty()) Text("Este vídeo não tem legendas", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Fechar", color = Color.White) } }
    )
}

@Composable
private fun TrackRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().tvClickable(onClick = onClick).padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected, null,
            colors = RadioButtonDefaults.colors(selectedColor = Color(0xFFE50914), unselectedColor = Color.Gray)
        )
        Text(label, color = Color.White)
    }
}
