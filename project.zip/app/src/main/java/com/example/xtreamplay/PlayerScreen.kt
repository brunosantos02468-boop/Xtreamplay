package com.example.xtreamplay

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.util.Rational
import android.view.View
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.focusable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.util.Locale

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Picture-in-picture (janela flutuante). */
fun enterPip(a: Activity?) {
    if (a != null && Build.VERSION.SDK_INT >= 26) {
        runCatching {
            a.enterPictureInPictureMode(
                PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
            )
        }
    }
}

private val resizeLabels = listOf("Ajustar", "Preencher", "Zoom")

@OptIn(UnstableApi::class)
private fun resizeConst(i: Int) = when (i) {
    1 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
    2 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    play: Play, initialResize: Int, startFullscreen: Boolean,
    onProgress: (Long, Long) -> Unit, onEnded: () -> Unit,
    hasPrev: Boolean = false, hasNext: Boolean = false,
    onPrev: () -> Unit = {}, onNext: () -> Unit = {},
    volumeBoost: Int = 1,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val activity = remember { ctx.findActivity() }
    val isTv = LocalIsTv.current
    val rootFocus = remember { FocusRequester() }
    val topFocus = remember { FocusRequester() }
    var rootFocused by remember { mutableStateOf(false) }
    var focusTopTick by remember { mutableIntStateOf(0) }
    var topFocused by remember { mutableStateOf(false) }
    var pv by remember { mutableStateOf<PlayerView?>(null) }
    var bottomFocused by remember { mutableStateOf(false) }
    var focusBottomTick by remember { mutableIntStateOf(0) }
    var ctlTick by remember { mutableIntStateOf(0) }
    var isPlayingState by remember { mutableStateOf(false) }
    var posMs by remember { mutableLongStateOf(0L) }
    var durMs by remember { mutableLongStateOf(0L) }
    val playFocus = remember { FocusRequester() }
    val player = remember {
        // Muitos servidores IPTV bloqueiam o User-Agent padrão do ExoPlayer e redirecionam
        // entre http/https. Por isso usamos um User-Agent comum e liberamos esses redirecionamentos.
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(20_000)
            .setReadTimeoutMs(30_000)
        // Buffer maior = menos travadas (principalmente em canais ao vivo e servidores lentos)
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(20_000, 60_000, 2_500, 5_000)
            .setTargetBufferBytes(32 * 1024 * 1024)
            .setPrioritizeTimeOverSizeThresholds(false)
            .build()
        ExoPlayer.Builder(ctx, DefaultRenderersFactory(ctx).setEnableDecoderFallback(true))
            .setLoadControl(load)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setMediaSourceFactory(DefaultMediaSourceFactory(ctx).setDataSourceFactory(http))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
    }
    // Reforço de volume: muitos vídeos IPTV (principalmente com som 5.1) saem baixos no estéreo.
    // O LoudnessEnhancer aumenta o ganho do áudio do próprio player (0, +6 dB ou +12 dB).
    val boostLevel by rememberUpdatedState(volumeBoost)
    val enhancer = remember { arrayOfNulls<LoudnessEnhancer>(1) }
    val applyBoost: (Int) -> Unit = { sessionId ->
        runCatching { enhancer[0]?.release() }
        enhancer[0] = null
        val gainMb = when (boostLevel) { 1 -> 600; 2 -> 1200; else -> 0 }
        if (gainMb > 0 && sessionId > 0) {
            runCatching {
                enhancer[0] = LoudnessEnhancer(sessionId).apply { setTargetGain(gainMb); setEnabled(true) }
            }
        }
    }
    val progress by rememberUpdatedState(onProgress)
    val ended by rememberUpdatedState(onEnded)

    var err by remember { mutableStateOf<String?>(null) }
    var fullscreen by remember { mutableStateOf(startFullscreen) }
    var resize by remember { mutableStateOf(initialResize) }
    var controls by remember { mutableStateOf(true) }
    // TV: os controles são nossos (selecionáveis pelo controle remoto); no celular, os do próprio player
    val showControls: () -> Unit = {
        if (isTv) { controls = true; ctlTick++ } else pv?.showController()
    }
    var tracks by remember { mutableStateOf(Tracks.EMPTY) }
    var showTracks by remember { mutableStateOf(false) }

    LaunchedEffect(play.url) {
        err = null
        player.setMediaItem(MediaItem.fromUri(play.url), play.startMs)
        player.prepare()
        player.playWhenReady = true
    }

    // Salva o progresso a cada 5 s (continuar assistindo)
    LaunchedEffect(play.url) {
        while (true) {
            delay(5000)
            if (player.isPlaying) progress(player.currentPosition, player.duration)
        }
    }

    // Tela cheia imersiva (barras do sistema ocultas + horizontal)
    LaunchedEffect(fullscreen) {
        val a = activity ?: return@LaunchedEffect
        val ctl = WindowCompat.getInsetsController(a.window, a.window.decorView)
        if (fullscreen) {
            a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctl.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ctl.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // Saiu do app (Home, outra janela...): pausa o vídeo, a não ser que esteja em janela flutuante (PiP)
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, player) {
        val obs = LifecycleEventObserver { _, ev ->
            if (ev == Lifecycle.Event.ON_STOP && activity?.isInPictureInPictureMode != true) player.pause()
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }
    DisposableEffect(player) {
        applyBoost(player.audioSessionId)
        val l = object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { applyBoost(audioSessionId) }
            override fun onPlayerError(error: PlaybackException) {
                val http = error.cause as? HttpDataSource.InvalidResponseCodeException
                err = if (http != null)
                    "Servidor recusou o vídeo (HTTP ${http.responseCode})"
                else
                    "Não foi possível reproduzir (${error.errorCodeName})"
            }
            override fun onTracksChanged(t: Tracks) { tracks = t }
            override fun onIsPlayingChanged(isPlaying: Boolean) { isPlayingState = isPlaying }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    val d = player.duration
                    if (d > 0) progress(d, d)
                    ended()
                }
            }
        }
        player.addListener(l)
        onDispose {
            runCatching { progress(player.currentPosition, player.duration) }
            player.removeListener(l)
            runCatching { enhancer[0]?.release() }
            enhancer[0] = null
            player.release()
            activity?.let { a ->
                a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.getInsetsController(a.window, a.window.decorView)
                    .show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }
    BackHandler(onBack = onBack)

    // TV: o foco começa no próprio player (setas controlam o vídeo)
    LaunchedEffect(Unit) { if (isTv) runCatching { rootFocus.requestFocus() } }
    LaunchedEffect(controls) { if (isTv && !controls) runCatching { rootFocus.requestFocus() } }
    // TV: esconde os controles depois de 5 s sem apertar nada (a não ser que esteja pausado ou navegando neles)
    LaunchedEffect(ctlTick) {
        if (isTv) {
            delay(5000)
            if (!topFocused && !bottomFocused && player.isPlaying) controls = false
        }
    }
    // Enquanto o foco estiver nos botões, os controles não somem
    LaunchedEffect(topFocused || bottomFocused) {
        while (topFocused || bottomFocused) { showControls(); delay(2500) }
    }
    // Barra de progresso: atualiza só enquanto os controles estão visíveis
    LaunchedEffect(controls) {
        while (isTv && controls) {
            posMs = player.currentPosition
            durMs = player.duration.coerceAtLeast(0L)
            delay(500)
        }
    }
    LaunchedEffect(focusTopTick) {
        if (focusTopTick > 0) { delay(80); runCatching { topFocus.requestFocus() } }
    }
    LaunchedEffect(focusBottomTick) {
        if (focusBottomTick > 0) { delay(80); runCatching { playFocus.requestFocus() } }
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .onPreviewKeyEvent { e ->
                if (isTv && e.type == KeyEventType.KeyDown) { controls = true; ctlTick++ }
                false
            }
            .onKeyEvent { e ->
                if (!isTv || !rootFocused || e.type != KeyEventType.KeyDown) return@onKeyEvent false
                when (e.key) {
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.MediaPlayPause -> {
                        if (player.isPlaying) player.pause() else player.play()
                        showControls(); true
                    }
                    Key.MediaPlay -> { player.play(); showControls(); true }
                    Key.MediaPause -> { player.pause(); showControls(); true }
                    Key.DirectionLeft, Key.MediaRewind -> { player.seekBack(); showControls(); true }
                    Key.DirectionRight, Key.MediaFastForward -> { player.seekForward(); showControls(); true }
                    Key.MediaNext -> { if (hasNext) onNext(); true }
                    Key.MediaPrevious -> { if (hasPrev) onPrev(); true }
                    Key.DirectionDown -> { showControls(); focusBottomTick++; true }
                    Key.DirectionUp -> { showControls(); focusTopTick++; true }
                    else -> false
                }
            }
            .focusRequester(rootFocus)
            .onFocusChanged { rootFocused = it.isFocused }
            .focusable()
    ) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    keepScreenOn = true
                    isFocusable = false
                    isFocusableInTouchMode = false
                    descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
                    pv = this
                    findViewById<View>(androidx.media3.ui.R.id.exo_settings)?.visibility = View.GONE
                    if (isTv) useController = false
                    else setControllerVisibilityListener(
                        PlayerView.ControllerVisibilityListener { v -> controls = v == View.VISIBLE }
                    )
                }
            },
            update = { it.resizeMode = resizeConst(resize) },
            modifier = Modifier.fillMaxSize()
        )

        AnimatedVisibility(controls, Modifier.align(Alignment.TopCenter)) {
            Row(
                Modifier.fillMaxWidth()
                    .onFocusChanged { topFocused = it.hasFocus }
                    .onKeyEvent { e ->
                        if (isTv && e.type == KeyEventType.KeyDown && e.key == Key.DirectionDown) {
                            runCatching { rootFocus.requestFocus() }; true
                        } else false
                    }
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                    .statusBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onBack, modifier = Modifier.tvFocusRing(RoundedCornerShape(50)).focusRequester(topFocus)) { Text("←", color = Color.White, fontSize = 24.sp) }
                Text(
                    play.title, color = Color.White, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { showTracks = true }, modifier = Modifier.tvFocusRing(RoundedCornerShape(50))) { Text("Áudio/Leg.", color = Color.White) }
                if (!isTv) TextButton(onClick = { enterPip(activity) }) { Text("PiP", color = Color.White) }
                TextButton(onClick = { resize = (resize + 1) % 3 }, modifier = Modifier.tvFocusRing(RoundedCornerShape(50))) {
                    Text(resizeLabels[resize], color = Color.White)
                }
                TextButton(onClick = { fullscreen = !fullscreen }, modifier = Modifier.tvFocusRing(RoundedCornerShape(50))) {
                    Text(if (fullscreen) "Sair da tela cheia" else "Tela cheia", color = Color.White)
                }
            }
        }

        if (isTv) AnimatedVisibility(controls, Modifier.align(Alignment.BottomCenter)) {
            TvControlsBar(
                isPlaying = isPlayingState, posMs = posMs, durMs = durMs,
                hasPrev = hasPrev, hasNext = hasNext, playFocus = playFocus,
                onPrev = { onPrev(); showControls() },
                onBack10 = { player.seekBack(); showControls() },
                onPlayPause = { if (player.isPlaying) player.pause() else player.play(); showControls() },
                onForward10 = { player.seekForward(); showControls() },
                onNext = { onNext(); showControls() },
                modifier = Modifier
                    .onFocusChanged { bottomFocused = it.hasFocus }
                    .focusGroup()
                    .onKeyEvent { e ->
                        if (e.type == KeyEventType.KeyDown && e.key == Key.DirectionUp) {
                            runCatching { rootFocus.requestFocus() }; true
                        } else false
                    }
            )
        }

        err?.let {
            Text(it, color = Color(0xFFFF6B6B), modifier = Modifier.align(Alignment.Center).padding(24.dp))
        }
    }

    if (showTracks) TracksDialog(player, tracks) { showTracks = false }
}

private fun trackLabel(g: Tracks.Group, i: Int): String {
    val f = g.getTrackFormat(i)
    val lang = f.language?.let { Locale(it).displayLanguage }?.takeIf { it.isNotBlank() }
    return f.label ?: lang ?: "Faixa ${i + 1}"
}

@Composable
private fun TracksDialog(player: ExoPlayer, tracks: Tracks, onClose: () -> Unit) {
    val audio = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
    val text = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
    val textDisabled = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
    val anyTextSelected = text.any { g -> (0 until g.length).any { g.isTrackSelected(it) } }

    fun pick(g: Tracks.Group, i: Int) {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(g.type, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
            .build()
        onClose()
    }

    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Atv.Surface,
        title = { Text("Áudio e legendas", color = Color.White) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("ÁUDIO", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                if (audio.isEmpty()) Text("Faixa padrão", color = Color.LightGray, modifier = Modifier.padding(vertical = 8.dp))
                audio.forEach { g ->
                    for (i in 0 until g.length) TrackRow(trackLabel(g, i), g.isTrackSelected(i)) { pick(g, i) }
                }
                Spacer(Modifier.height(12.dp))
                Text("LEGENDAS", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                TrackRow("Desativadas", textDisabled || !anyTextSelected) {
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                    onClose()
                }
                text.forEach { g ->
                    for (i in 0 until g.length) TrackRow(trackLabel(g, i), !textDisabled && g.isTrackSelected(i)) { pick(g, i) }
                }
                if (text.isEmpty()) Text("Este vídeo não tem legendas", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Fechar", color = Color.White) } }
    )
}

@Composable
private fun TrackRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().tvClickable(onClick = onClick).padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected, null,
            colors = RadioButtonDefaults.colors(selectedColor = Color.White, unselectedColor = Color.Gray)
        )
        Text(label, color = Color.White)
    }
}
