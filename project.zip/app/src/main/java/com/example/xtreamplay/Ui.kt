package com.example.xtreamplay

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val tv = remember { detectTv(ctx) }
    CompositionLocalProvider(LocalIsTv provides tv) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = Color.White, onPrimary = Color.Black, background = Color.Black, surface = Atv.Surface,
                surfaceVariant = Atv.SurfaceHi, onBackground = Color.White, onSurface = Color.White
            ),
            content = content
        )
    }
}

/* ---------- Login (Xtream Codes) ---------- */

@Composable
fun LoginScreen(vm: AppViewModel) {
    var server by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    val serverFocus = remember { FocusRequester() }
    if (LocalIsTv.current) LaunchedEffect(Unit) { delay(400); runCatching { serverFocus.requestFocus() } }

    Column(
        Modifier.fillMaxSize().background(Color.Black)
            .padding(horizontal = if (LocalIsTv.current) 220.dp else 28.dp, vertical = 28.dp)
            .statusBarsPadding().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            PrismaLogo(48.dp)
            Spacer(Modifier.width(12.dp))
            Text("PRISMA", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text("Entre com seu acesso Xtream Codes", color = Color.LightGray)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            server, { server = it }, Modifier.fillMaxWidth().focusRequester(serverFocus).tvKeyboardOnOk(), singleLine = true,
            label = { Text("Servidor (ex: http://exemplo.com:8080)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next)
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            user, { user = it }, Modifier.fillMaxWidth().tvKeyboardOnOk(), singleLine = true, label = { Text("Usuário") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            pass, { pass = it }, Modifier.fillMaxWidth().tvKeyboardOnOk(), singleLine = true, label = { Text("Senha") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done)
        )
        vm.error?.let { Text(it, color = Color(0xFFFF6B6B), modifier = Modifier.padding(top = 12.dp)) }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { vm.login(server, user, pass) },
            enabled = !vm.loading,
            modifier = Modifier.fillMaxWidth().height(52.dp).tvFocusRing(RoundedCornerShape(20.dp)),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
        ) {
            if (vm.loading) CircularProgressIndicator(Modifier.size(22.dp), color = Color.Black, strokeWidth = 2.dp)
            else Text("Entrar", fontWeight = FontWeight.Bold)
        }
    }
}

/* ---------- Home ---------- */

@Composable
fun HomeScreen(vm: AppViewModel) {
    val d = vm.derived[vm.tab]
    val shelves = d?.shelves.orEmpty()
    val hero = remember(d) { d?.items?.firstOrNull { it.image != null } }
    val top10 = d?.top10.orEmpty()

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PrismaLogo(30.dp)
            Spacer(Modifier.width(8.dp))
            Text("PRISMA", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
            Spacer(Modifier.weight(1f))
            Avatar(vm.profile?.name.orEmpty(), 32, profileColor(vm.profile)) { vm.go(Screen.MORE) }
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Kind.values().forEach { k ->
                Chip(k.label, vm.tab == k) { vm.selectTab(k) }
            }
        }

        Box(Modifier.fillMaxSize()) {
            LazyColumn(Modifier.fillMaxSize()) {
                if (hero != null) item {
                    Hero(hero, vm.isFav(hero), { vm.toggleFav(hero) }) { vm.playNow(hero) }
                }
                if (vm.recent.isNotEmpty()) item {
                    Column {
                        Text(
                            "Continuar assistindo", color = Color.White, fontWeight = FontWeight.SemiBold,
                            fontSize = if (LocalIsTv.current) 22.sp else 18.sp, modifier = Modifier.padding(start = 12.dp, top = 18.dp, bottom = 8.dp)
                        )
                        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            items(vm.recent.toList()) { r -> RecentCard(r, { vm.removeRecent(r) }) { vm.resume(r) } }
                        }
                    }
                }
                if (top10.isNotEmpty()) item { TopTenRow(Shelf("Top 10", top10), vm) }
                items(shelves) { shelf -> PosterRow(shelf, vm) }
                item { Spacer(Modifier.height(32.dp)) }
            }
            if (vm.loading) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
            if (!vm.loading && d != null && shelves.isEmpty()) {
                Text(
                    if (vm.profile?.kids == true) "Nenhuma categoria infantil encontrada neste servidor"
                    else "Nenhum item encontrado",
                    color = Color.Gray, modifier = Modifier.align(Alignment.Center).padding(24.dp)
                )
            }
            vm.error?.let {
                Text(it, color = Color(0xFFFF6B6B), modifier = Modifier.align(Alignment.Center).padding(24.dp))
            }
        }
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    val pill = RoundedCornerShape(50)
    Box(
        Modifier.clip(pill)
            .background(if (selected) Color.White else Color(0x26FFFFFF))
            .tvClickable(pill, onClick)
            .padding(horizontal = 18.dp, vertical = 8.dp)
    ) {
        Text(
            label, color = if (selected) Color.Black else Color.White,
            fontSize = if (LocalIsTv.current) 16.sp else 14.sp, fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun PosterRow(shelf: Shelf, vm: AppViewModel) {
    val title = shelf.title
    val list = shelf.items
    Column {
        Text(
            title, color = Color.White, fontWeight = FontWeight.SemiBold,
            fontSize = if (LocalIsTv.current) 22.sp else 18.sp, modifier = Modifier.padding(start = 12.dp, top = 18.dp, bottom = 8.dp)
        )
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(list) { Poster(it, vm.isFav(it), { vm.toggleFav(it) }) { vm.open(it) } }
        }
    }
}

@Composable
private fun TopTenRow(shelf: Shelf, vm: AppViewModel) {
    val list = shelf.items
    Column {
        Text(
            "Top 10 — mais bem avaliados", color = Color.White, fontWeight = FontWeight.SemiBold,
            fontSize = if (LocalIsTv.current) 22.sp else 18.sp, modifier = Modifier.padding(start = 12.dp, top = 18.dp, bottom = 8.dp)
        )
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(list) { i, t ->
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        "${i + 1}", color = Color(0xFF666666), fontSize = 88.sp,
                        fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(end = 2.dp)
                    )
                    Poster(t, vm.isFav(t), { vm.toggleFav(t) }) { vm.open(t) }
                }
            }
        }
    }
}

@Composable
private fun Hero(item: Item, isFav: Boolean, onFav: () -> Unit, onPlay: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(if (LocalIsTv.current) 300.dp else 420.dp)) {
        AsyncImage(item.image, item.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000), Color.Black))
            )
        )
        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            Text(item.name, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onPlay, modifier = Modifier.height(46.dp).tvFocusRing(RoundedCornerShape(50)), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) {
                    Text("▶  Assistir", fontWeight = FontWeight.Bold)
                }
                Button(onClick = onFav, modifier = Modifier.height(46.dp).tvFocusRing(RoundedCornerShape(50)), colors = ButtonDefaults.buttonColors(containerColor = Color(0x40FFFFFF), contentColor = Color.White)) {
                    Text(if (isFav) "✓  Minha lista" else "+  Minha lista", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Poster(item: Item, isFav: Boolean, onFav: () -> Unit, onClick: () -> Unit) {
    val wide = item.kind == Kind.LIVE
    Column(Modifier.width(if (wide) 190.dp else 150.dp).tvCombinedClickable(RoundedCornerShape(16.dp), onClick, onFav)) {
        Box(
            Modifier.fillMaxWidth().height(if (wide) 120.dp else 225.dp)
                .clip(RoundedCornerShape(14.dp)).background(Atv.Surface),
            contentAlignment = Alignment.Center
        ) {
            if (item.image != null)
                AsyncImage(item.image, item.name, Modifier.fillMaxSize(), contentScale = if (wide) ContentScale.Fit else ContentScale.Crop)
            else Text(item.name.take(2).uppercase(), color = Color.Gray, fontSize = 26.sp)
            if (isFav || !LocalIsTv.current) Box(
                Modifier.align(Alignment.TopEnd).padding(6.dp).size(if (isFav) 26.dp else 30.dp).clip(CircleShape)
                    .background(if (isFav) Atv.Red else Color(0x99000000))
                    .then(if (LocalIsTv.current) Modifier else Modifier.clickable(onClick = onFav)),
                contentAlignment = Alignment.Center
            ) {
                Text(if (isFav) "♥" else "♡", color = Color.White, fontSize = if (isFav) 14.sp else 17.sp)
            }
        }
        Text(item.name, color = Color.LightGray, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun RecentCard(r: Recent, onRemove: () -> Unit, onClick: () -> Unit) {
    val prog = if (r.durationMs > 0) (r.positionMs.toFloat() / r.durationMs).coerceIn(0f, 1f) else 0f
    Column(Modifier.width(210.dp).tvCombinedClickable(RoundedCornerShape(16.dp), onClick, onRemove)) {
        Box(Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(14.dp)).background(Atv.Surface)) {
            if (r.item.image != null)
                AsyncImage(r.item.image, r.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(
                Modifier.align(Alignment.Center).size(44.dp).clip(CircleShape).background(Color(0x99000000)),
                contentAlignment = Alignment.Center
            ) { Text("▶", color = Color.White, fontSize = 18.sp) }
            if (!LocalIsTv.current) Text(
                "✕", color = Color.White,
                modifier = Modifier.align(Alignment.TopEnd).padding(10.dp).clickable(onClick = onRemove)
            )
            LinearProgressIndicator(
                progress = { prog },
                modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp),
                color = Color.White, trackColor = Color(0x66FFFFFF)
            )
        }
        Text(r.title, color = Color.LightGray, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun Avatar(user: String, size: Int, color: Color = Atv.Blue, onClick: (() -> Unit)? = null) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape(10.dp)).background(color)
            .then(if (onClick != null) Modifier.tvClickable(RoundedCornerShape(10.dp), onClick) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Text(user.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size / 2).sp)
    }
}
