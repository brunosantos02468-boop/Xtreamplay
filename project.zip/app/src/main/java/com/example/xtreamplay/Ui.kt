package com.example.xtreamplay

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val Red = Color(0xFFE50914)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red, background = Color.Black, surface = Color(0xFF141414),
            onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}

/* ---------- Login (Xtream Codes) ---------- */

@Composable
fun LoginScreen(vm: AppViewModel) {
    var server by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().background(Color.Black).padding(28.dp).statusBarsPadding(),
        verticalArrangement = Arrangement.Center
    ) {
        Text("XTREAMPLAY", color = Red, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(6.dp))
        Text("Entre com seu acesso Xtream Codes", color = Color.LightGray)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            server, { server = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("Servidor (ex: http://exemplo.com:8080)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(user, { user = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Usuário") })
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            pass, { pass = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Senha") },
            visualTransformation = PasswordVisualTransformation()
        )
        vm.error?.let { Text(it, color = Color(0xFFFF6B6B), modifier = Modifier.padding(top = 12.dp)) }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { vm.login(server, user, pass) },
            enabled = !vm.loading,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Red)
        ) {
            if (vm.loading) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
            else Text("Entrar", fontWeight = FontWeight.Bold)
        }
    }
}

/* ---------- Home estilo Netflix ---------- */

@Composable
fun HomeScreen(vm: AppViewModel) {
    val shelves = vm.shelves[vm.tab].orEmpty()
    val hero = shelves.flatMap { it.items }.firstOrNull { it.image != null }

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("XTREAMPLAY", color = Red, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.weight(1f))
            Avatar(vm.profile?.name.orEmpty(), 32, profileColor(vm.profile)) { vm.go(Screen.MORE) }
        }
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Kind.values().forEach { k ->
                val sel = vm.tab == k
                Box(
                    Modifier.clip(RoundedCornerShape(50))
                        .background(if (sel) Color(0xFF333333) else Color.Transparent)
                        .border(1.dp, if (sel) Color.White else Color.Gray, RoundedCornerShape(50))
                        .clickable { vm.selectTab(k) }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) { Text(k.label, color = Color.White, fontSize = 14.sp) }
            }
        }

        Box(Modifier.fillMaxSize()) {
            LazyColumn(Modifier.fillMaxSize()) {
                if (hero != null) item { Hero(hero, vm.isFav(hero), { vm.toggleFav(hero) }) { vm.open(hero) } }
                if (vm.recent.isNotEmpty()) item {
                    Text(
                        "Continuar assistindo", color = Color.White, fontWeight = FontWeight.Bold,
                        fontSize = 17.sp, modifier = Modifier.padding(start = 12.dp, top = 18.dp, bottom = 8.dp)
                    )
                    LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(vm.recent.toList()) { r -> RecentCard(r, { vm.removeRecent(r) }) { vm.resume(r) } }
                    }
                }
                items(shelves) { shelf ->
                    Text(
                        shelf.title, color = Color.White, fontWeight = FontWeight.Bold,
                        fontSize = 17.sp, modifier = Modifier.padding(start = 12.dp, top = 18.dp, bottom = 8.dp)
                    )
                    LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(shelf.items) { Poster(it, vm.isFav(it), { vm.toggleFav(it) }) { vm.open(it) } }
                    }
                }
                item { Spacer(Modifier.height(32.dp)) }
            }
            if (vm.loading) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Red)
            vm.error?.let {
                Text(it, color = Color(0xFFFF6B6B), modifier = Modifier.align(Alignment.Center).padding(24.dp))
            }
        }
    }

}

@Composable
private fun Hero(item: Item, isFav: Boolean, onFav: () -> Unit, onPlay: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(380.dp)) {
        AsyncImage(item.image, item.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Transparent, Color.Black), startY = 350f)
            )
        )
        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            Text(item.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) {
                    Text("▶  Assistir", fontWeight = FontWeight.Bold)
                }
                Button(onClick = onFav, colors = ButtonDefaults.buttonColors(containerColor = Color(0x66FFFFFF), contentColor = Color.White)) {
                    Text(if (isFav) "✓  Minha lista" else "+  Minha lista", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Poster(item: Item, isFav: Boolean, onFav: () -> Unit, onClick: () -> Unit) {
    val wide = item.kind == Kind.LIVE
    Column(Modifier.width(if (wide) 190.dp else 150.dp).combinedClickable(onClick = onClick, onLongClick = onFav)) {
        Box(
            Modifier.fillMaxWidth().height(if (wide) 120.dp else 225.dp)
                .clip(RoundedCornerShape(8.dp)).background(Color(0xFF222222)),
            contentAlignment = Alignment.Center
        ) {
            if (item.image != null)
                AsyncImage(item.image, item.name, Modifier.fillMaxSize(), contentScale = if (wide) ContentScale.Fit else ContentScale.Crop)
            else Text(item.name.take(2).uppercase(), color = Color.Gray, fontSize = 26.sp)
            Box(
                Modifier.align(Alignment.TopEnd).padding(6.dp).size(30.dp).clip(CircleShape)
                    .background(Color(0x99000000)).clickable(onClick = onFav),
                contentAlignment = Alignment.Center
            ) {
                Text(if (isFav) "♥" else "♡", color = if (isFav) Red else Color.White, fontSize = 17.sp)
            }
        }
        Text(item.name, color = Color.LightGray, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun SeriesDialog(vm: AppViewModel) {
    AlertDialog(
        onDismissRequest = { vm.closeSeries() },
        containerColor = Color(0xFF141414),
        title = { Text(vm.openSeries?.name.orEmpty(), color = Color.White) },
        text = {
            if (vm.episodes.isEmpty()) CircularProgressIndicator(color = Red)
            else LazyColumn {
                var last = -1
                vm.episodes.forEach { ep ->
                    if (ep.season != last) {
                        last = ep.season
                        item { Text("Temporada ${ep.season}", color = Red, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp)) }
                    }
                    item {
                        Text(ep.title, color = Color.White, modifier = Modifier.fillMaxWidth().clickable { vm.playEpisode(ep) }.padding(vertical = 10.dp))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.closeSeries() }) { Text("Fechar", color = Color.White) } }
    )
}

@Composable
fun Avatar(user: String, size: Int, color: Color = Red, onClick: (() -> Unit)? = null) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape(4.dp)).background(color)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Text(user.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size / 2).sp)
    }
}

@Composable
fun RecentCard(r: Recent, onRemove: () -> Unit, onClick: () -> Unit) {
    val prog = if (r.durationMs > 0) (r.positionMs.toFloat() / r.durationMs).coerceIn(0f, 1f) else 0f
    Column(Modifier.width(210.dp).clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF222222))) {
            if (r.item.image != null)
                AsyncImage(r.item.image, r.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Text("▶", color = Color.White, fontSize = 30.sp, modifier = Modifier.align(Alignment.Center))
            Text(
                "✕", color = Color.White,
                modifier = Modifier.align(Alignment.TopEnd).padding(10.dp).clickable(onClick = onRemove)
            )
            LinearProgressIndicator(
                progress = { prog },
                modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp),
                color = Red, trackColor = Color(0x66FFFFFF)
            )
        }
        Text(r.title, color = Color.LightGray, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
    }
}
