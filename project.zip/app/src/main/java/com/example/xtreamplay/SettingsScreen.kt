package com.example.xtreamplay

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val resizeLabels = listOf("Ajustar", "Preencher", "Zoom")
private val boostLabels = listOf("Desligado", "Médio (+6 dB)", "Alto (+12 dB)")
private val formatLabels = mapOf("m3u8" to "HLS (m3u8)", "ts" to "MPEG-TS (ts)")

@Composable
fun SettingsScreen(vm: AppViewModel) {
    BackHandler { vm.go(Screen.HOME) }
    var dialog by remember { mutableStateOf<String?>(null) }
    val c = vm.creds

    Column(
        Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()
            .verticalScroll(rememberScrollState())
    ) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.go(Screen.HOME) }, modifier = Modifier.tvFocusRing(RoundedCornerShape(50))) {
                Text("←", color = Color.White, fontSize = 24.sp)
            }
            Text("Configurações do app", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        // Perfil
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(vm.profile?.name.orEmpty(), 56, profileColor(vm.profile))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(c?.user.orEmpty(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(c?.server.orEmpty(), color = Color.Gray, fontSize = 13.sp)
            }
        }

        Section("Reprodução")
        SwitchRow("Tela cheia automática", "Abrir o player em tela cheia na horizontal", vm.autoFullscreen) {
            vm.updateAutoFullscreen(it)
        }
        ChoiceRow("Proporção do vídeo", resizeLabels[vm.resizeMode]) { dialog = "resize" }
        ChoiceRow("Reforço de volume", boostLabels[vm.volumeBoost.coerceIn(0, 2)]) { dialog = "boost" }
        ChoiceRow("Formato dos canais ao vivo", formatLabels[vm.liveFormat] ?: vm.liveFormat) { dialog = "format" }
        SwitchRow("Ocultar conteúdo adulto", "Esconde categorias adultas nas listas", vm.hideAdult) { vm.updateHideAdult(it) }

        Section("Listas")
        ActionRow("Atualizar listas", "Recarregar canais, filmes e séries do servidor") {
            vm.refresh(); vm.go(Screen.HOME)
        }

        Section("Perfil")
        ActionRow("Trocar perfil", "Escolher quem está assistindo") { vm.switchProfile() }
        ActionRow("PIN do perfil", if (vm.profile?.pin.orEmpty().isNotEmpty()) "Ativado — toque para alterar ou remover" else "Proteger este perfil com 4 dígitos") { dialog = "pin" }

        Section("Conta")
        ActionRow("Sair", "Desconectar deste servidor", color = Atv.Red) { vm.logout() }

        Section("Sobre")
        Text("Prisma 1.2", color = Color.Gray, modifier = Modifier.padding(16.dp))
        Spacer(Modifier.height(32.dp))
    }

    when (dialog) {
        "pin" -> PinDialog(vm) { dialog = null }
        "resize" -> OptionsDialog(
            "Proporção do vídeo", resizeLabels, vm.resizeMode,
            { vm.updateResizeMode(it); dialog = null }, { dialog = null }
        )
        "boost" -> OptionsDialog(
            "Reforço de volume", boostLabels, vm.volumeBoost.coerceIn(0, 2),
            { vm.updateVolumeBoost(it); dialog = null }, { dialog = null }
        )
        "format" -> {
            val keys = formatLabels.keys.toList()
            OptionsDialog(
                "Formato dos canais ao vivo", keys.map { formatLabels[it]!! }, keys.indexOf(vm.liveFormat),
                { vm.updateLiveFormat(keys[it]); dialog = null }, { dialog = null }
            )
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(
        title.uppercase(), color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 4.dp)
    )
    HorizontalDivider(color = Atv.Divider)
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().tvClickable { onChange(!checked) }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 16.sp)
            Text(subtitle, color = Color.Gray, fontSize = 13.sp)
        }
        Switch(
            checked, null,
            colors = SwitchDefaults.colors(checkedTrackColor = Atv.Green, checkedThumbColor = Color.White)
        )
    }
    HorizontalDivider(color = Atv.SurfaceHi)
}

@Composable
private fun ChoiceRow(title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().tvClickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text(value, color = Color.Gray, fontSize = 14.sp)
    }
    HorizontalDivider(color = Atv.SurfaceHi)
}

@Composable
private fun ActionRow(title: String, subtitle: String, color: Color = Color.White, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().tvClickable(onClick = onClick).padding(16.dp)) {
        Text(title, color = color, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Text(subtitle, color = Color.Gray, fontSize = 13.sp)
    }
    HorizontalDivider(color = Atv.SurfaceHi)
}

@Composable
private fun OptionsDialog(
    title: String, options: List<String>, selected: Int,
    onSelect: (Int) -> Unit, onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Atv.Surface,
        title = { Text(title, color = Color.White) },
        text = {
            Column {
                options.forEachIndexed { i, label ->
                    Row(
                        Modifier.fillMaxWidth().tvClickable { onSelect(i) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected == i, null,
                            colors = RadioButtonDefaults.colors(selectedColor = Color.White, unselectedColor = Color.Gray)
                        )
                        Text(label, color = Color.White)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar", color = Color.White) } }
    )
}

@Composable
private fun PinDialog(vm: AppViewModel, onClose: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    val hasPin = vm.profile?.pin.orEmpty().isNotEmpty()
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Atv.Surface,
        title = { Text("PIN do perfil", color = Color.White) },
        text = {
            Column {
                Text("Quem escolher este perfil precisará digitar o PIN.", color = Color.Gray, fontSize = 13.sp)
                OutlinedTextField(
                    pin, { pin = it.filter { c -> c.isDigit() }.take(4) },
                    singleLine = true, label = { Text("Novo PIN (4 dígitos)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.padding(top = 12.dp).tvKeyboardOnOk()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { if (pin.length == 4) { vm.setPin(pin); onClose() } }) {
                Text("Salvar", color = Color.White)
            }
        },
        dismissButton = {
            if (hasPin) TextButton(onClick = { vm.setPin(""); onClose() }) { Text("Remover PIN", color = Color(0xFFFF6B6B)) }
            else TextButton(onClick = onClose) { Text("Cancelar", color = Color.Gray) }
        }
    )
}
