package com.example.xtreamplay

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache

/** Guarda as imagens (pôsteres e logos) no aparelho para não baixar de novo. */
class PrismaApp : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .allowRgb565(true) // menos memória e decodificação mais rápida em TVs fracas
        .respectCacheHeaders(false) // servidores IPTV costumam proibir cache; ignoramos isso
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.25).build() }
        .diskCache {
            DiskCache.Builder()
                .directory(cacheDir.resolve("images"))
                .maxSizeBytes(300L * 1024 * 1024)
                .build()
        }
        .build()
}
