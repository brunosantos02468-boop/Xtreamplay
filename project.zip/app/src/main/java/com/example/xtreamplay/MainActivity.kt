package com.example.xtreamplay

import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { App(vm) } }
    }

    private val tvMode by lazy { detectTv(this) }

    // TV: se nenhum item está com foco, a seta apertada acorda o foco em vez de ser perdida
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (tvMode && event.action == KeyEvent.ACTION_DOWN && !TvFocus.hasFocus && isDpadKey(event.keyCode)) {
            val now = System.currentTimeMillis()
            if (now - TvFocus.lastKickAt > 800) {
                TvFocus.lastKickAt = now
                TvFocus.kick++
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun isDpadKey(code: Int) = code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN ||
        code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT ||
        code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER

    // Ao apertar "Home" durante um vídeo, vira janela flutuante (PiP)
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (vm.playing != null) enterPip(this)
    }
}

@Composable
fun App(vm: AppViewModel) {
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(1200); splash = false }

    val play = vm.playing
    val appReq = remember { FocusRequester() }
    LaunchedEffect(TvFocus.kick) {
        if (TvFocus.kick > 0) runCatching { appReq.requestFocus() }
    }
    Box(
        Modifier.fillMaxSize()
            .onFocusChanged { TvFocus.hasFocus = it.hasFocus }
            .focusRequester(appReq)
            .focusGroup()
    ) {
        when {
            splash -> SplashScreen()
            vm.creds == null -> LoginScreen(vm)
            vm.profile == null -> ProfileScreen(vm)
            play != null -> PlayerScreen(
                play, vm.resizeMode, vm.autoFullscreen,
                { pos, dur -> vm.saveProgress(play, pos, dur) },
                { vm.playNextEpisode() }
            ) { vm.playing = null }
            else -> MainScaffold(vm)
        }
    }
}

@Composable
fun SplashScreen() {
    var started by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { started = true }
    val a by animateFloatAsState(if (started) 1f else 0f, tween(1000), label = "splash")

    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.graphicsLayer {
                alpha = a
                scaleX = 0.7f + 0.3f * a
                scaleY = 0.7f + 0.3f * a
            }
        ) {
            PrismaLogo(130.dp)
            Spacer(Modifier.height(16.dp))
            Text(
                "PRISMA", color = Color.White, fontSize = 34.sp,
                fontWeight = FontWeight.ExtraBold, letterSpacing = 8.sp
            )
        }
    }
}
