package com.example.xtreamplay

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { App(vm) } }
    }
}

@Composable
fun App(vm: AppViewModel) {
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(1800); splash = false }

    val play = vm.playing
    when {
        splash -> SplashScreen()
        vm.creds == null -> LoginScreen(vm)
        vm.profile == null -> ProfileScreen(vm)
        play != null -> PlayerScreen(
            play, vm.resizeMode, vm.autoFullscreen,
            { pos, dur -> vm.saveProgress(play, pos, dur) }
        ) { vm.playing = null }
        else -> MainScaffold(vm)
    }
}

@Composable
fun SplashScreen() {
    var started by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { started = true }
    val a by animateFloatAsState(if (started) 1f else 0f, tween(900), label = "splash")

    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Text(
            "XTREAMPLAY",
            color = Color(0xFFE50914),
            fontSize = 40.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.graphicsLayer {
                alpha = a
                scaleX = 0.6f + 0.4f * a
                scaleY = 0.6f + 0.4f * a
            }
        )
    }
}
