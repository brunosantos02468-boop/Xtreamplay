package com.example.xtreamplay

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** Cliente da API Xtream Codes (player_api.php). */
class XtreamApi(private val c: Credentials) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private suspend fun call(action: String? = null, extra: String = ""): String =
        withContext(Dispatchers.IO) {
            var url = "${c.server}/player_api.php?username=${enc(c.user)}&password=${enc(c.pass)}"
            if (action != null) url += "&action=$action"
            url += extra
            val req = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0").build()
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) error("Servidor respondeu ${r.code}")
                r.body?.string().orEmpty()
            }
        }

    suspend fun login() {
        val info = JSONObject(call()).optJSONObject("user_info")
            ?: error("Resposta inválida do servidor")
        if (info.optString("auth") != "1") error("Usuário ou senha incorretos")
        if (info.optString("status").equals("Expired", ignoreCase = true)) error("Assinatura expirada")
    }

    private suspend fun array(action: String): JSONArray =
        runCatching { JSONArray(call(action)) }.getOrDefault(JSONArray())

    suspend fun shelves(kind: Kind): List<Shelf> {
        val (catAction, listAction) = when (kind) {
            Kind.LIVE -> "get_live_categories" to "get_live_streams"
            Kind.MOVIE -> "get_vod_categories" to "get_vod_streams"
            Kind.SERIES -> "get_series_categories" to "get_series"
        }
        val catArr = array(catAction)
        val cats = LinkedHashMap<String, String>()
        for (i in 0 until catArr.length()) {
            val o = catArr.getJSONObject(i)
            cats[o.optString("category_id")] = o.optString("category_name")
        }

        val arr = array(listAction)
        val items = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            when (kind) {
                Kind.LIVE -> Item(
                    o.optString("stream_id"), o.optString("name"),
                    o.optString("stream_icon").ifBlank { null },
                    o.optString("category_id"), kind
                )
                Kind.MOVIE -> Item(
                    o.optString("stream_id"), o.optString("name"),
                    o.optString("stream_icon").ifBlank { null },
                    o.optString("category_id"), kind,
                    o.optString("container_extension").ifBlank { "mp4" }
                )
                Kind.SERIES -> Item(
                    o.optString("series_id"), o.optString("name"),
                    o.optString("cover").ifBlank { null },
                    o.optString("category_id"), kind
                )
            }
        }
        val grouped = items.groupBy { it.category }
        return cats.mapNotNull { (id, name) ->
            grouped[id]?.let { Shelf(name, it) }
        }
    }

    suspend fun episodes(seriesId: String): List<Episode> {
        val root = JSONObject(call("get_series_info", "&series_id=$seriesId"))
        val eps = root.optJSONObject("episodes") ?: return emptyList()
        val out = mutableListOf<Episode>()
        for (key in eps.keys()) {
            val arr = eps.optJSONArray(key) ?: continue
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += Episode(
                    o.optString("id"),
                    o.optString("title").ifBlank { "Episódio ${o.optString("episode_num")}" },
                    key.toIntOrNull() ?: 0,
                    o.optString("container_extension").ifBlank { "mp4" }
                )
            }
        }
        return out.sortedWith(compareBy({ it.season }, { it.title }))
    }

    fun liveUrl(id: String, ext: String = "m3u8") = "${c.server}/live/${c.user}/${c.pass}/$id.$ext"
    fun movieUrl(id: String, ext: String) = "${c.server}/movie/${c.user}/${c.pass}/$id.$ext"
    fun episodeUrl(id: String, ext: String) = "${c.server}/series/${c.user}/${c.pass}/$id.$ext"
}
