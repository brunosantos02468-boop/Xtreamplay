package com.example.xtreamplay

data class Credentials(val server: String, val user: String, val pass: String)

enum class Kind(val label: String) { LIVE("Canais"), MOVIE("Filmes"), SERIES("Séries") }

data class Item(
    val id: String,
    val name: String,
    val image: String?,
    val category: String,
    val kind: Kind,
    val ext: String = ""
)

data class Shelf(val title: String, val items: List<Item>)

data class Episode(val id: String, val title: String, val season: Int, val ext: String)

data class Play(val url: String, val title: String, val item: Item? = null, val startMs: Long = 0)

data class Recent(val item: Item, val url: String, val title: String, val positionMs: Long, val durationMs: Long)

data class Profile(val id: String, val name: String, val color: Int)

enum class Screen { HOME, SEARCH, LIST, MORE }
