package com.example.xtreamplay

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.view.View
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private val resizeLabels = listOf("Ajustar", "Preencher", "Zoom")

@OptIn(UnstableApi::class)
private fun resizeConst(i: Int) = when (i) {
    1 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
    2 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(play: Play, initialResize: Int, startFullscreen: Boolean, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val activity = remember { ctx.findActivity() }
    val player = remember { ExoPlayer.Builder(ctx).build() }
    var err by remember { mutableStateOf<String?>(null) }
    var fullscreen by remember { mutableStateOf(startFullscreen) }
    var resize by remember { mutableStateOf(initialResize) }
    var controls by remember { mutableStateOf(true) }

    LaunchedEffect(play.url) {
        err = null
        player.setMediaItem(MediaItem.fromUri(play.url))
        player.prepare()
        player.playWhenReady = true
    }

    // Tela cheia imersiva (barras do sistema ocultas + horizontal)
    LaunchedEffect(fullscreen) {
        val a = activity ?: return@LaunchedEffect
        val ctl = WindowCompat.getInsetsController(a.window, a.window.decorView)
        if (fullscreen) {
            a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctl.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ctl.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                err = "Não foi possível reproduzir (${error.errorCodeName})"
            }
        }
        player.addListener(l)
        onDispose {
            player.removeListener(l)
            player.release()
            activity?.let { a ->
                a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.getInsetsController(a.window, a.window.decorView)
                    .show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }
    BackHandler(onBack = onBack)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    keepScreenOn = true
                    setControllerVisibilityListener(
                        PlayerView.ControllerVisibilityListener { v -> controls = v == View.VISIBLE }
                    )
                }
            },
            update = { it.resizeMode = resizeConst(resize) },
            modifier = Modifier.fillMaxSize()
        )

        AnimatedVisibility(controls, Modifier.align(Alignment.TopCenter)) {
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                    .statusBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onBack) { Text("←", color = Color.White, fontSize = 24.sp) }
                Text(
                    play.title, color = Color.White, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { resize = (resize + 1) % 3 }) {
                    Text(resizeLabels[resize], color = Color.White)
                }
                TextButton(onClick = { fullscreen = !fullscreen }) {
                    Text(if (fullscreen) "Sair da tela cheia" else "Tela cheia", color = Color.White)
                }
            }
        }

        err?.let {
            Text(it, color = Color(0xFFFF6B6B), modifier = Modifier.align(Alignment.Center).padding(24.dp))
        }
    }
}
